<?php return array('𪛖'=>'𪛖');
