<?php exit; ?>
1547076129
SELECT * FROM phpbb_styles s WHERE s.style_id = 2
295
a:1:{i:0;a:8:{s:8:"style_id";s:1:"2";s:10:"style_name";s:13:"prosilver_mod";s:15:"style_copyright";s:22:"© phpBB Limited, 2007";s:12:"style_active";s:1:"1";s:10:"style_path";s:13:"prosilver_mod";s:15:"bbcode_bitfield";s:4:"//g=";s:15:"style_parent_id";s:1:"0";s:17:"style_parent_tree";s:0:"";}}