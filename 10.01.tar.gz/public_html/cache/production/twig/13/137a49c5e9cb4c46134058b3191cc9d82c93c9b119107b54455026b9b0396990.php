<?php

/* forumlist_body.html */
class __TwigTemplate_e4e1b53c39b011d09a997aed101042e93164e358e254235f8a64831ccdcdd37c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "forumrow", array()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["forumrow"]) {
            // line 2
            echo "
\t
";
            // line 4
            if (( !$this->getAttribute($context["forumrow"], "S_IS_CAT", array()) && $this->getAttribute($context["forumrow"], "S_FIRST_ROW", array()))) {
                // line 5
                echo "\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 7
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 8
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\"></td>
\t\t\t<td style=\"background:url(";
                // line 9
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/cu.png) repeat;\" width=\"300\" height=\"48\"><h4 align=\"center\"><a href=\"";
                echo $this->getAttribute($context["forumrow"], "U_VIEWFORUM", array());
                echo "\">";
                echo $this->getAttribute($context["forumrow"], "FORUM_NAME", array());
                echo " </a></h4></td>
\t\t\t<td style=\"background:url(";
                // line 10
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\" align=\"right\">
\t\t\t";
                // line 11
                if (( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null) && (isset($context["U_MARK_FORUMS"]) ? $context["U_MARK_FORUMS"] : null))) {
                    echo "<h6><a class=\"navf\" href=\"";
                    echo (isset($context["U_MARK_FORUMS"]) ? $context["U_MARK_FORUMS"] : null);
                    echo "\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MARK_FORUMS_READ");
                    echo "</a>&nbsp;</h6>";
                }
                echo "</td>
\t\t\t<td><img src=\"";
                // line 12
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t</tr>
\t</table>\t
\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td style=\"background:url(";
                // line 17
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_08.png) repeat;\" width=\"41\" height=\"100%\"></td>
\t\t\t<td>
\t\t\t\t<table class=\"tablebg\" onmouseover=\"this.className='tablebg2'\" onmouseout=\"this.className='tablebg'\" cellspacing=\"1\" width=\"100%\">
\t\t\t\t\t<tr>
\t\t\t\t\t    <th colspan=\"2\">&nbsp;";
                // line 21
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM");
                echo "&nbsp;</th>
\t\t\t\t\t    <th width=\"50\">&nbsp;";
                // line 22
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPICS");
                echo "&nbsp;</th>
\t\t\t\t\t    <th width=\"50\">&nbsp;";
                // line 23
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POSTS");
                echo "&nbsp;</th>
\t\t\t\t\t    <th>&nbsp;";
                // line 24
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LAST_POST");
                echo "&nbsp;</th>
\t\t\t\t\t</tr>

\t";
            }
            // line 28
            echo "\t";
            if ($this->getAttribute($context["forumrow"], "S_IS_CAT", array())) {
                // line 29
                echo "\t";
                if ( !$this->getAttribute($context["forumrow"], "S_FIRST_ROW", array())) {
                    // line 30
                    echo "\t\t\t\t</table>
\t\t\t</td>
\t\t\t<td style=\"background:url(";
                    // line 32
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_09.png) repeat;\" width=\"41\" height=\"100%\"></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td><img src=\"";
                    // line 35
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                    // line 36
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_11.png) repeat;\" width=\"100%\" height=\"46\"></td>
\t\t\t<td><img src=\"";
                    // line 37
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t</tr>
\t</table>\t
\t\t
\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td><img src=\"";
                    // line 43
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                    // line 44
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\"></td>
\t\t\t<td style=\"background:url(";
                    // line 45
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/cu.png) repeat;\" width=\"300\" height=\"48\">
\t\t\t<h4 align=\"center\">";
                    // line 46
                    if ($this->getAttribute($context["forumrow"], "S_IS_CAT", array())) {
                        echo "<a href=\"";
                        echo $this->getAttribute($context["forumrow"], "U_VIEWFORUM", array());
                        echo "\">";
                        echo $this->getAttribute($context["forumrow"], "FORUM_NAME", array());
                        echo " </a>";
                    } else {
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM");
                    }
                    echo "</h4>
\t\t\t</td>
\t\t\t<td style=\"background:url(";
                    // line 48
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\"></td>
\t\t\t<td><img src=\"";
                    // line 49
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t</tr>
\t</table>
\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td style=\"background:url(";
                    // line 54
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_08.png) repeat;\" width=\"41\" height=\"100%\"></td>
\t\t\t<td>\t
\t\t\t\t<table class=\"tablebg\" onmouseover=\"this.className='tablebg2'\" onmouseout=\"this.className='tablebg'\" cellspacing=\"1\" width=\"100%\">
\t\t\t\t
\t\t\t\t\t\t
\t ";
                } else {
                    // line 60
                    echo "\t
\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td><img src=\"";
                    // line 63
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                    // line 64
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\"></td>
\t\t\t<td style=\"background:url(";
                    // line 65
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/cu.png) repeat;\" width=\"300\" height=\"48\"><h4 align=\"center\"><a href=\"";
                    echo $this->getAttribute($context["forumrow"], "U_VIEWFORUM", array());
                    echo "\">";
                    echo $this->getAttribute($context["forumrow"], "FORUM_NAME", array());
                    echo "</a></h4></td>
\t\t\t<td style=\"background:url(";
                    // line 66
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\" align=\"right\"> 
\t\t\t";
                    // line 67
                    if (( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null) && (isset($context["U_MARK_FORUMS"]) ? $context["U_MARK_FORUMS"] : null))) {
                        echo "<h6><a class=\"navf\" href=\"";
                        echo (isset($context["U_MARK_FORUMS"]) ? $context["U_MARK_FORUMS"] : null);
                        echo "\">";
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MARK_FORUMS_READ");
                        echo "</a>&nbsp;</h6>";
                    }
                    echo "</td>
\t\t\t<td><img src=\"";
                    // line 68
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t</tr>
\t</table>
\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td style=\"background:url(";
                    // line 73
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/box_08.png) repeat;\" width=\"41\" height=\"100%\"></td>
\t\t\t<td> 
\t\t\t\t<table class=\"tablebg\" onmouseover=\"this.className='tablebg2'\" onmouseout=\"this.className='tablebg'\" cellspacing=\"1\" width=\"100%\">
\t";
                }
                // line 77
                echo "\t\t\t\t\t<tr>
\t\t\t\t\t    <th colspan=\"2\">&nbsp;";
                // line 78
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM");
                echo "&nbsp;</th>
\t\t\t\t\t    <th width=\"50\">&nbsp;";
                // line 79
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPICS");
                echo "&nbsp;</th>
\t\t\t\t\t    <th width=\"50\">&nbsp;";
                // line 80
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POSTS");
                echo "&nbsp;</th>
\t\t\t\t\t    <th>&nbsp;";
                // line 81
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LAST_POST");
                echo "&nbsp;</th>
\t\t\t\t\t</tr>
\t\t";
            } elseif ($this->getAttribute(            // line 83
$context["forumrow"], "S_IS_LINK", array())) {
                // line 84
                echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"row1\" onmouseover=\"this.className='row4'\" onmouseout=\"this.className='row1'\" width=\"50\" align=\"center\">";
                // line 85
                echo $this->getAttribute($context["forumrow"], "FORUM_FOLDER_IMG", array());
                echo "</td>
\t\t\t\t\t\t<td class=\"row1\" onmouseover=\"this.className='row4'\" onmouseout=\"this.className='row1'\">
\t\t\t\t\t\t";
                // line 87
                if ($this->getAttribute($context["forumrow"], "FORUM_IMAGE", array())) {
                    // line 88
                    echo "\t\t\t\t\t\t<div style=\"float: ";
                    echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
                    echo "; margin-";
                    echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
                    echo ": 5px;\">";
                    echo $this->getAttribute($context["forumrow"], "FORUM_IMAGE", array());
                    echo "</div>
\t\t\t\t\t\t";
                }
                // line 90
                echo "\t\t\t\t\t\t<a class=\"forumlink\" href=\"";
                echo $this->getAttribute($context["forumrow"], "U_VIEWFORUM", array());
                echo "\">";
                echo $this->getAttribute($context["forumrow"], "FORUM_NAME", array());
                echo "</a>
\t\t\t\t\t\t<p class=\"forumdesc\">";
                // line 91
                echo $this->getAttribute($context["forumrow"], "FORUM_DESC", array());
                echo "</p>
\t\t\t\t\t\t</td>
\t\t\t\t\t\t";
                // line 93
                if ($this->getAttribute($context["forumrow"], "CLICKS", array())) {
                    // line 94
                    echo "\t\t\t\t\t\t<td class=\"row2\" colspan=\"3\" align=\"center\"><span class=\"genmed\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("REDIRECTS");
                    echo ": ";
                    echo $this->getAttribute($context["forumrow"], "CLICKS", array());
                    echo "</span></td>
\t\t\t\t\t\t";
                } else {
                    // line 96
                    echo "\t\t\t\t\t\t<td class=\"row2\" colspan=\"3\" align=\"center\">&nbsp;</td>
\t\t\t\t\t";
                }
                // line 98
                echo "\t\t\t\t\t</tr>
\t\t\t\t\t";
            } else {
                // line 100
                echo "\t\t\t\t\t";
                if ($this->getAttribute($context["forumrow"], "S_NO_CAT", array())) {
                    // line 101
                    echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"cat\" colspan=\"2\"><h4>";
                    // line 102
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM");
                    echo "</h4></td>
\t\t\t\t\t\t<td class=\"catdiv\" colspan=\"3\">&nbsp;</td>
\t\t\t\t\t</tr>
\t\t\t\t\t";
                }
                // line 106
                echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"row1\" onmouseover=\"this.className='row4'\" onmouseout=\"this.className='row1'\" width=\"50\" align=\"center\">";
                // line 107
                echo $this->getAttribute($context["forumrow"], "FORUM_FOLDER_IMG", array());
                echo "</td>
\t\t\t\t\t\t<td class=\"row1\" onmouseover=\"this.className='row4'\" onmouseout=\"this.className='row1'\" width=\"100%\">
\t\t\t\t\t\t";
                // line 109
                if ($this->getAttribute($context["forumrow"], "FORUM_IMAGE", array())) {
                    // line 110
                    echo "\t\t\t\t\t\t<div style=\"float: ";
                    echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
                    echo "; margin-";
                    echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
                    echo ": 5px;\">";
                    echo $this->getAttribute($context["forumrow"], "FORUM_IMAGE", array());
                    echo "</div>
\t\t\t\t\t\t";
                }
                // line 112
                echo "\t\t\t\t\t\t<a class=\"forumlink\" href=\"";
                echo $this->getAttribute($context["forumrow"], "U_VIEWFORUM", array());
                echo "\">";
                echo $this->getAttribute($context["forumrow"], "FORUM_NAME", array());
                echo "</a>
\t\t\t\t\t\t<p class=\"forumdesc\">";
                // line 113
                echo $this->getAttribute($context["forumrow"], "FORUM_DESC", array());
                echo "</p>
\t\t\t\t\t\t";
                // line 114
                if ($this->getAttribute($context["forumrow"], "MODERATORS", array())) {
                    // line 115
                    echo "\t\t\t\t\t\t<p class=\"forumdesc\"><strong>";
                    echo $this->getAttribute($context["forumrow"], "L_MODERATOR_STR", array());
                    echo ":</strong> ";
                    echo $this->getAttribute($context["forumrow"], "MODERATORS", array());
                    echo "</p>
\t\t\t\t\t\t";
                }
                // line 117
                echo "\t\t\t\t\t    ";
                if (($this->getAttribute($context["forumrow"], "SUBFORUMS", array()) && $this->getAttribute($context["forumrow"], "S_LIST_SUBFORUMS", array()))) {
                    // line 118
                    echo "\t\t\t\t\t\t<p class=\"forumdesc\"><strong>";
                    echo $this->getAttribute($context["forumrow"], "L_SUBFORUM_STR", array());
                    echo "</strong> ";
                    echo $this->getAttribute($context["forumrow"], "SUBFORUMS", array());
                    echo "</p>
\t\t\t\t\t\t";
                }
                // line 120
                echo "\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td class=\"row2\" onmouseover=\"this.className='row4'\" onmouseout=\"this.className='row2'\" align=\"center\"><p class=\"topicdetails\">";
                // line 121
                echo $this->getAttribute($context["forumrow"], "TOPICS", array());
                echo "</p></td>
\t\t\t\t\t\t<td class=\"row2\" onmouseover=\"this.className='row4'\" onmouseout=\"this.className='row2'\" align=\"center\"><p class=\"topicdetails\">";
                // line 122
                echo $this->getAttribute($context["forumrow"], "POSTS", array());
                echo "</p></td>
\t\t\t\t\t\t<td class=\"row2\" onmouseover=\"this.className='row4'\" onmouseout=\"this.className='row2'\" align=\"center\" nowrap=\"nowrap\">
\t\t\t\t\t\t";
                // line 124
                if ($this->getAttribute($context["forumrow"], "LAST_POST_TIME", array())) {
                    // line 125
                    echo "\t\t\t\t\t\t<p class=\"topicdetails\"><a href=\"";
                    echo $this->getAttribute($context["forumrow"], "U_LAST_POST", array());
                    echo "\" title=\"";
                    echo $this->getAttribute($context["forumrow"], "LAST_POST_SUBJECT", array());
                    echo "\">";
                    echo $this->getAttribute($context["forumrow"], "LAST_POST_SHORTENED_SUBJECT", array());
                    echo "</a></p>
\t\t\t\t\t\t<p class=\"topicdetails\">";
                    // line 126
                    if ($this->getAttribute($context["forumrow"], "U_UNAPPROVED_TOPICS", array())) {
                        echo "<a href=\"";
                        echo $this->getAttribute($context["forumrow"], "U_UNAPPROVED_TOPICS", array());
                        echo "\">";
                        echo (isset($context["UNAPPROVED_IMG"]) ? $context["UNAPPROVED_IMG"] : null);
                        echo "</a>&nbsp;";
                    }
                    echo $this->getAttribute($context["forumrow"], "LAST_POST_TIME", array());
                    echo "</p>
\t\t\t\t\t\t<p class=\"topicdetails\">";
                    // line 127
                    echo $this->getAttribute($context["forumrow"], "LAST_POSTER_FULL", array());
                    echo "
\t\t\t\t\t\t";
                    // line 128
                    if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
                        echo "<a href=\"";
                        echo $this->getAttribute($context["forumrow"], "U_LAST_POST", array());
                        echo "\">";
                        echo (isset($context["LAST_POST_IMG"]) ? $context["LAST_POST_IMG"] : null);
                        echo "</a>";
                    }
                    // line 129
                    echo "\t\t\t\t\t\t</p>
\t\t\t\t\t\t";
                } else {
                    // line 131
                    echo "\t\t\t\t\t\t<p class=\"topicdetails\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_POSTS");
                    echo "</p>
\t\t\t\t\t\t";
                }
                // line 133
                echo "\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t\t";
            }
            // line 136
            echo "\t";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 137
            echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"row1\" colspan=\"5\" align=\"center\"><p class=\"gensmall\">";
            // line 138
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_FORUMS");
            echo "</p></td>
\t\t\t\t\t</tr>
\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['forumrow'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 141
        echo "\t\t\t\t</table>
\t\t\t</td>
\t\t\t<td style=\"background:url(";
        // line 143
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_09.png) repeat;\" width=\"41\" height=\"100%\"></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td><img src=\"";
        // line 146
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
        // line 147
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_11.png) repeat;\" width=\"100%\" height=\"46\"></td>
\t\t\t<td><img src=\"";
        // line 148
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t</tr>
\t</table>
\t\t\t";
    }

    public function getTemplateName()
    {
        return "forumlist_body.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  460 => 148,  456 => 147,  452 => 146,  446 => 143,  442 => 141,  433 => 138,  430 => 137,  425 => 136,  420 => 133,  414 => 131,  410 => 129,  402 => 128,  398 => 127,  387 => 126,  378 => 125,  376 => 124,  371 => 122,  367 => 121,  364 => 120,  356 => 118,  353 => 117,  345 => 115,  343 => 114,  339 => 113,  332 => 112,  322 => 110,  320 => 109,  315 => 107,  312 => 106,  305 => 102,  302 => 101,  299 => 100,  295 => 98,  291 => 96,  283 => 94,  281 => 93,  276 => 91,  269 => 90,  259 => 88,  257 => 87,  252 => 85,  249 => 84,  247 => 83,  242 => 81,  238 => 80,  234 => 79,  230 => 78,  227 => 77,  220 => 73,  212 => 68,  202 => 67,  198 => 66,  190 => 65,  186 => 64,  182 => 63,  177 => 60,  168 => 54,  160 => 49,  156 => 48,  143 => 46,  139 => 45,  135 => 44,  131 => 43,  122 => 37,  118 => 36,  114 => 35,  108 => 32,  104 => 30,  101 => 29,  98 => 28,  91 => 24,  87 => 23,  83 => 22,  79 => 21,  72 => 17,  64 => 12,  54 => 11,  50 => 10,  42 => 9,  38 => 8,  34 => 7,  30 => 5,  28 => 4,  24 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "forumlist_body.html", "");
    }
}
