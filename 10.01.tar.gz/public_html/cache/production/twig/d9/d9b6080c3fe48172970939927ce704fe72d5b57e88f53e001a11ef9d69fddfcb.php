<?php

/* overall_header.html */
class __TwigTemplate_88525e6a03515c8133f61fb3a8a76e165835621dac2f0162c35df87e3e6b21b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" dir=\"";
        // line 2
        echo (isset($context["S_CONTENT_DIRECTION"]) ? $context["S_CONTENT_DIRECTION"] : null);
        echo "\" lang=\"";
        echo (isset($context["S_USER_LANG"]) ? $context["S_USER_LANG"] : null);
        echo "\" xml:lang=\"";
        echo (isset($context["S_USER_LANG"]) ? $context["S_USER_LANG"] : null);
        echo "\">
<head>

<meta http-equiv=\"content-type\" content=\"text/html; charset=";
        // line 5
        echo (isset($context["S_CONTENT_ENCODING"]) ? $context["S_CONTENT_ENCODING"] : null);
        echo "\" />
<meta http-equiv=\"content-language\" content=\"";
        // line 6
        echo (isset($context["S_USER_LANG"]) ? $context["S_USER_LANG"] : null);
        echo "\" />
<meta http-equiv=\"content-style-type\" content=\"text/css\" />
<meta http-equiv=\"imagetoolbar\" content=\"no\" />
<meta name=\"resource-type\" content=\"document\" />
<meta name=\"distribution\" content=\"global\" />
<meta name=\"copyright\" content=\"2000, 2002, 2005, 2007 phpBB Group\" />
<meta name=\"keywords\" content=\"\" />
<meta name=\"description\" content=\"\" />
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=EmulateIE7; IE=EmulateIE9\" />
";
        // line 15
        echo (isset($context["META"]) ? $context["META"] : null);
        echo "
<title>";
        // line 16
        echo (isset($context["SITENAME"]) ? $context["SITENAME"] : null);
        echo " &bull; ";
        if ((isset($context["S_IN_MCP"]) ? $context["S_IN_MCP"] : null)) {
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MCP");
            echo " &bull; ";
        } elseif ((isset($context["S_IN_UCP"]) ? $context["S_IN_UCP"] : null)) {
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("UCP");
            echo " &bull; ";
        }
        echo (isset($context["PAGE_TITLE"]) ? $context["PAGE_TITLE"] : null);
        echo "</title>

";
        // line 18
        if ((isset($context["S_ENABLE_FEEDS"]) ? $context["S_ENABLE_FEEDS"] : null)) {
            // line 19
            echo "\t";
            if ((isset($context["S_ENABLE_FEEDS_OVERALL"]) ? $context["S_ENABLE_FEEDS_OVERALL"] : null)) {
                echo "<link rel=\"alternate\" type=\"application/atom+xml\" title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED");
                echo " - ";
                echo (isset($context["SITENAME"]) ? $context["SITENAME"] : null);
                echo "\" href=\"";
                echo (isset($context["U_FEED"]) ? $context["U_FEED"] : null);
                echo "\" />";
            }
            // line 20
            echo "\t";
            if ((isset($context["S_ENABLE_FEEDS_NEWS"]) ? $context["S_ENABLE_FEEDS_NEWS"] : null)) {
                echo "<link rel=\"alternate\" type=\"application/atom+xml\" title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED");
                echo " - ";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED_NEWS");
                echo "\" href=\"";
                echo (isset($context["U_FEED"]) ? $context["U_FEED"] : null);
                echo "?mode=news\" />";
            }
            // line 21
            echo "\t";
            if ((isset($context["S_ENABLE_FEEDS_FORUMS"]) ? $context["S_ENABLE_FEEDS_FORUMS"] : null)) {
                echo "<link rel=\"alternate\" type=\"application/atom+xml\" title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED");
                echo " - ";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ALL_FORUMS");
                echo "\" href=\"";
                echo (isset($context["U_FEED"]) ? $context["U_FEED"] : null);
                echo "?mode=forums\" />";
            }
            // line 22
            echo "\t";
            if ((isset($context["S_ENABLE_FEEDS_TOPICS"]) ? $context["S_ENABLE_FEEDS_TOPICS"] : null)) {
                echo "<link rel=\"alternate\" type=\"application/atom+xml\" title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED");
                echo " - ";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED_TOPICS_NEW");
                echo "\" href=\"";
                echo (isset($context["U_FEED"]) ? $context["U_FEED"] : null);
                echo "?mode=topics\" />";
            }
            // line 23
            echo "\t";
            if ((isset($context["S_ENABLE_FEEDS_TOPICS_ACTIVE"]) ? $context["S_ENABLE_FEEDS_TOPICS_ACTIVE"] : null)) {
                echo "<link rel=\"alternate\" type=\"application/atom+xml\" title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED");
                echo " - ";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED_TOPICS_ACTIVE");
                echo "\" href=\"";
                echo (isset($context["U_FEED"]) ? $context["U_FEED"] : null);
                echo "?mode=topics_active\" />";
            }
            // line 24
            echo "\t";
            if (((isset($context["S_ENABLE_FEEDS_FORUM"]) ? $context["S_ENABLE_FEEDS_FORUM"] : null) && (isset($context["S_FORUM_ID"]) ? $context["S_FORUM_ID"] : null))) {
                echo "<link rel=\"alternate\" type=\"application/atom+xml\" title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED");
                echo " - ";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM");
                echo " - ";
                echo (isset($context["FORUM_NAME"]) ? $context["FORUM_NAME"] : null);
                echo "\" href=\"";
                echo (isset($context["U_FEED"]) ? $context["U_FEED"] : null);
                echo "?f=";
                echo (isset($context["S_FORUM_ID"]) ? $context["S_FORUM_ID"] : null);
                echo "\" />";
            }
            // line 25
            echo "\t";
            if (((isset($context["S_ENABLE_FEEDS_TOPIC"]) ? $context["S_ENABLE_FEEDS_TOPIC"] : null) && (isset($context["S_TOPIC_ID"]) ? $context["S_TOPIC_ID"] : null))) {
                echo "<link rel=\"alternate\" type=\"application/atom+xml\" title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FEED");
                echo " - ";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC");
                echo " - ";
                echo (isset($context["TOPIC_TITLE"]) ? $context["TOPIC_TITLE"] : null);
                echo "\" href=\"";
                echo (isset($context["U_FEED"]) ? $context["U_FEED"] : null);
                echo "?f=";
                echo (isset($context["S_FORUM_ID"]) ? $context["S_FORUM_ID"] : null);
                echo "&amp;t=";
                echo (isset($context["S_TOPIC_ID"]) ? $context["S_TOPIC_ID"] : null);
                echo "\" />";
            }
        }
        // line 27
        echo "
<link rel=\"stylesheet\" href=\"";
        // line 28
        echo (isset($context["T_STYLESHEET_LINK"]) ? $context["T_STYLESHEET_LINK"] : null);
        echo "\" type=\"text/css\" />


<script type=\"text/javascript\">
// <![CDATA[
";
        // line 33
        if ((isset($context["S_USER_PM_POPUP"]) ? $context["S_USER_PM_POPUP"] : null)) {
            // line 34
            echo "if (";
            echo (isset($context["S_NEW_PM"]) ? $context["S_NEW_PM"] : null);
            echo ")
{
popup('";
            // line 36
            echo (isset($context["UA_POPUP_PM"]) ? $context["UA_POPUP_PM"] : null);
            echo "', 400, 225, '_phpbbprivmsg');
}
";
        }
        // line 39
        echo "
function popup(url, width, height, name)
{
if (!name)
{
name = '_popup';
}

window.open(url.replace(/&amp;/g, '&'), name, 'height=' + height + ',resizable=yes,scrollbars=yes,width=' + width);
return false;
}

function jumpto()
{
var page = prompt('";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("JUMP_PAGE"), "js");
        echo ":', '";
        echo (isset($context["ON_PAGE"]) ? $context["ON_PAGE"] : null);
        echo "');
var per_page = '";
        // line 54
        echo (isset($context["PER_PAGE"]) ? $context["PER_PAGE"] : null);
        echo "';
\tvar base_url = '";
        // line 55
        echo (isset($context["A_BASE_URL"]) ? $context["A_BASE_URL"] : null);
        echo "';

\tif (page !== null && !isNaN(page) && page == Math.floor(page) && page > 0)
\t{
\t\tif (base_url.indexOf('?') == -1)
\t\t{
\t\t\tdocument.location.href = base_url + '?start=' + ((page - 1) * per_page);
\t\t}
\t\telse
\t\t{
\t\t\tdocument.location.href = base_url.replace(/&amp;/g, '&') + '&start=' + ((page - 1) * per_page);
\t\t}
\t}
}

/**
* Find a member
*/
function find_username(url)
{
popup(url, 760, 570, '_usersearch');
return false;
}

/**
* Mark/unmark checklist
* id = ID of parent container, name = name prefix, state = state [true/false]
*/
function marklist(id, name, state)
{
var parent = document.getElementById(id);
if (!parent)
{
eval('parent = document.' + id);
}

if (!parent)
{
return;
}

var rb = parent.getElementsByTagName('input');

for (var r = 0; r < rb.length; r++)
{
if (rb[r].name.substr(0, name.length) == name)
{
rb[r].checked = state;
}
}
}

";
        // line 107
        if (twig_length_filter($this->env, $this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "_file", array()))) {
            // line 108
            echo "
/**
* Play quicktime file by determining it's width/height
* from the displayed rectangle area
*
* Only defined if there is a file block present.
*/
function play_qt_file(obj)
{
var rectangle = obj.GetRectangle();

if (rectangle)
{
rectangle = rectangle.split(',')
var x1 = parseInt(rectangle[0]);
var x2 = parseInt(rectangle[2]);
var y1 = parseInt(rectangle[1]);
var y2 = parseInt(rectangle[3]);

var width = (x1 < 0) ? (x1 * -1) + x2 : x2 - x1;
var height = (y1 < 0) ? (y1 * -1) + y2 : y2 - y1;
}
else
{
var width = 200;
var height = 0;
}

obj.width = width;
obj.height = height + 16;

obj.SetControllerVisible(true);

obj.Play();
}
";
        }
        // line 144
        echo "
// ]]>
</script>
<script type=\"text/javascript\">
<!--
// copyright 1999 Idocs, Inc. http://www.idocs.com/tags/
// Distribute this script freely, but please keep this
// notice with the code.

var rollOverArr=new Array();
function setrollover(OverImgSrc,pageImageName)
{
if (! document.images)return;
if (pageImageName == null)
pageImageName = document.images[document.images.length-1].name;
rollOverArr[pageImageName]=new Object;
rollOverArr[pageImageName].overImg = new Image;
rollOverArr[pageImageName].overImg.src=OverImgSrc;
}

function rollover(pageImageName)
{
if (! document.images)return;
if (! rollOverArr[pageImageName])return;
if (! rollOverArr[pageImageName].outImg)
{
rollOverArr[pageImageName].outImg = new Image;
rollOverArr[pageImageName].outImg.src = document.images[pageImageName].src;
}
document.images[pageImageName].src=rollOverArr[pageImageName].overImg.src;
}

function rollout(pageImageName)
{
if (! document.images)return;
if (! rollOverArr[pageImageName])return;
document.images[pageImageName].src=rollOverArr[pageImageName].outImg.src;
}
//-->
</script>

</head>
<body class=\"";
        // line 186
        echo (isset($context["S_CONTENT_DIRECTION"]) ? $context["S_CONTENT_DIRECTION"] : null);
        echo "\">

<a name=\"top\"></a>

<div id=\"wrapheader\">
\t<table id=\"bx\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td>
\t\t\t<table style=\"height:40;\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t<tr>
\t\t\t\t<td><img src=\"";
        // line 196
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h11.png\" width=\"40\" height=\"40\" alt=\"\" /></td>
\t\t\t\t<td><img src=\"";
        // line 197
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h12.png\" width=\"100\" height=\"40\" alt=\"\" /></td>
\t\t\t\t<td style=\"background:url(";
        // line 198
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h13.png) repeat;\" width=\"100%\" height=\"40\"></td>
\t\t\t\t<td><img src=\"";
        // line 199
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h14.png\" width=\"100\" height=\"40\" alt=\"\" /></td>
\t\t\t\t<td><img src=\"";
        // line 200
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h15.png\" width=\"40\" height=\"40\" alt=\"\" /></td>
\t\t\t</tr>
\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t<td>
\t\t\t<table style=\"height:140;\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t<tr>
\t\t\t\t<td><img src=\"";
        // line 209
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h21.png\" width=\"40\" height=\"140\" alt=\"\" /></td>
\t\t\t\t<td><img src=\"";
        // line 210
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h22.png\" width=\"100\" height=\"140\" alt=\"\" /></td>
\t\t\t\t<td style=\"background:url(";
        // line 211
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h23.png) repeat;\" width=\"100%\" height=\"140\">
\t\t\t
\t\t\t\t\t<div id=\"logodesc\">
\t\t\t\t\t\t<table width=\"100%\" cellspacing=\"0\">
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td><a href=\"";
        // line 216
        echo (isset($context["U_INDEX"]) ? $context["U_INDEX"] : null);
        echo "\">";
        echo (isset($context["SITE_LOGO_IMG"]) ? $context["SITE_LOGO_IMG"] : null);
        echo "</a></td>
\t\t\t\t\t\t\t\t<td width=\"100%\" align=\"center\"><h1>";
        // line 217
        echo (isset($context["SITENAME"]) ? $context["SITENAME"] : null);
        echo "</h1><span class=\"gen\">";
        echo (isset($context["SITE_DESCRIPTION"]) ? $context["SITE_DESCRIPTION"] : null);
        echo "</span></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</table>
\t\t\t\t\t</div>
\t\t\t\t</td>
\t\t\t\t<td><img src=\"";
        // line 222
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h24.png\" width=\"100\" height=\"140\" alt=\"\" /></td>
\t\t\t\t<td><img src=\"";
        // line 223
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h25.png\" width=\"40\" height=\"140\" alt=\"\" /></td>
\t\t\t</tr>
\t\t\t</table>
\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t<td>
\t\t\t<table width=\"100%\" style=\"height=66;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t<tr>
\t\t\t\t<td><img src=\"";
        // line 232
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h31.png\" width=\"40\" height=\"66\" alt=\"\" /></td>
\t\t\t\t<td><img src=\"";
        // line 233
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h32.png\" width=\"100\" height=\"66\" alt=\"\" /></td>
\t\t\t\t<td style=\"background:url(";
        // line 234
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h33.png);\" class=\"header_buttons\" align=\"center\">
\t\t\t\t\t<table width=\"100%\">
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td class=\"button_img\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 238
        echo (isset($context["U_INDEX"]) ? $context["U_INDEX"] : null);
        echo "\"
\t\t\t\t\t\t\t\tonmouseover = \"rollover('home')\"
\t\t\t\t\t\t\t\tonmouseout = \"rollout('home')\"
\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t<img src=\"";
        // line 242
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/buttons/home1.png\"
\t\t\t\t\t\t\t\tname=\"home\"
\t\t\t\t\t\t\t\talt=\"Home Page\" border=\"0\"
\t\t\t\t\t\t\t\theight=\"40\" width=\"101\"
\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\tsetrollover(\"";
        // line 250
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/buttons/home2.png\");
\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td class=\"button_img\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 255
        echo (isset($context["U_FAQ"]) ? $context["U_FAQ"] : null);
        echo "\"
\t\t\t\t\t\t\t\tonmouseover = \"rollover('faq')\"
\t\t\t\t\t\t\t\tonmouseout = \"rollout('faq')\"
\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t<img src=\"";
        // line 259
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/buttons/faq1.png\"
\t\t\t\t\t\t\t\tname=\"faq\"
\t\t\t\t\t\t\t\talt=\"FAQ\" border=\"0\"
\t\t\t\t\t\t\t\theight=\"40\" width=\"101\"
\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\tsetrollover(\"";
        // line 267
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/buttons/faq2.png\");
\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td class=\"button_img\">
\t\t\t\t\t\t\t\t";
        // line 272
        if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
            // line 273
            echo "\t\t\t\t\t\t\t\t\t<a href=\"";
            echo (isset($context["U_TEAM"]) ? $context["U_TEAM"] : null);
            echo "\"
\t\t\t\t\t\t\t\t\tonmouseover = \"rollover('team')\"
\t\t\t\t\t\t\t\t\tonmouseout = \"rollout('team')\"
\t\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 277
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/team1.png\"
\t\t\t\t\t\t\t\t\tname=\"team\"
\t\t\t\t\t\t\t\t\talt=\"Team\" border=\"0\"
\t\t\t\t\t\t\t\t\theight=\"40\" width=\"101\"
\t\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\tsetrollover(\"";
            // line 285
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/team2.png\");
\t\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\t";
        }
        // line 289
        echo "\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td class=\"button_img\">
\t\t\t\t\t\t\t\t";
        // line 291
        if ((isset($context["S_DISPLAY_SEARCH"]) ? $context["S_DISPLAY_SEARCH"] : null)) {
            // line 292
            echo "\t\t\t\t\t\t\t\t\t<a href=\"";
            echo (isset($context["U_SEARCH"]) ? $context["U_SEARCH"] : null);
            echo "\"
\t\t\t\t\t\t\t\t\tonmouseover = \"rollover('search')\"
\t\t\t\t\t\t\t\t\tonmouseout = \"rollout('search')\"
\t\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 296
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/search1.png\"
\t\t\t\t\t\t\t\t\tname=\"search\"
\t\t\t\t\t\t\t\t\talt=\"Search\" border=\"0\"
\t\t\t\t\t\t\t\t\theight=\"40\" width=\"101\"
\t\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\tsetrollover(\"";
            // line 304
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/search2.png\");
\t\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\t";
        }
        // line 308
        echo "\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td class=\"button_img\">
\t\t\t\t\t\t\t\t";
        // line 310
        if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
            // line 311
            echo "\t\t\t\t\t\t\t\t\t";
            if ((isset($context["S_DISPLAY_MEMBERLIST"]) ? $context["S_DISPLAY_MEMBERLIST"] : null)) {
                // line 312
                echo "\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo (isset($context["U_MEMBERLIST"]) ? $context["U_MEMBERLIST"] : null);
                echo "\"
\t\t\t\t\t\t\t\t\t\tonmouseover = \"rollover('members')\"
\t\t\t\t\t\t\t\t\t\tonmouseout = \"rollout('members')\"
\t\t\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t\t\t<img src=\"";
                // line 316
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/buttons/members1.png\"
\t\t\t\t\t\t\t\t\t\tname=\"members\"
\t\t\t\t\t\t\t\t\t\talt=\"Members\" border=\"0\"
\t\t\t\t\t\t\t\t\t\theight=\"40\" width=\"101\"
\t\t\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\t\tsetrollover(\"";
                // line 324
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/buttons/members2.png\");
\t\t\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\t\t";
            }
            // line 328
            echo "\t\t\t\t\t\t\t\t";
        }
        // line 329
        echo "\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</table>            
\t\t\t\t</td>
\t\t\t\t<td><img src=\"";
        // line 333
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h34.png\" width=\"100\" height=\"66\" alt=\"\" /></td>
\t\t\t\t<td><img src=\"";
        // line 334
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/header/h35.png\" width=\"40\" height=\"66\" alt=\"\" /></td>
\t\t\t</tr>
\t\t\t</table>
\t\t</td>
\t\t</tr>
\t</table>
</div>

<div id=\"wrapcentre\">
\t<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t<td>
\t\t\t<table  style=\"height=45;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\">
\t\t\t<tr>
\t\t\t\t<td><img src=\"";
        // line 348
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_01.png\" width=\"61\" height=\"45\" alt=\"\" /></td>
\t\t\t\t<td style=\"background:url(";
        // line 349
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_02.png) repeat;\" width=\"20%\" height=\"45\"></td>
\t\t\t\t<td><img src=\"";
        // line 350
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/cu_l.png\" width=\"44\" height=\"45\" alt=\"\" /></td>
\t\t\t\t<td style=\"background:url(";
        // line 351
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/cu_m.png);\" width=\"20%\" height=\"45\" align=\"center\">
\t\t\t\t\t<h5>
\t\t\t\t\t\t";
        // line 353
        if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
            // line 354
            echo "\t\t\t\t\t\t\t";
            if ((isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null)) {
                // line 355
                echo "\t\t\t\t\t\t\t\t";
                if ((isset($context["S_DISPLAY_PM"]) ? $context["S_DISPLAY_PM"] : null)) {
                    echo " &nbsp;<a href=\"";
                    echo (isset($context["U_PRIVATEMSGS"]) ? $context["U_PRIVATEMSGS"] : null);
                    echo "\"> ";
                    echo (isset($context["PRIVATE_MESSAGE_INFO"]) ? $context["PRIVATE_MESSAGE_INFO"] : null);
                    echo "
\t\t\t\t\t\t\t\t\t";
                    // line 356
                    if ((isset($context["PRIVATE_MESSAGE_INFO_UNREAD"]) ? $context["PRIVATE_MESSAGE_INFO_UNREAD"] : null)) {
                        echo ", ";
                        echo (isset($context["PRIVATE_MESSAGE_INFO_UNREAD"]) ? $context["PRIVATE_MESSAGE_INFO_UNREAD"] : null);
                        echo "
\t\t\t\t\t\t\t\t\t";
                    }
                    // line 357
                    echo "</a>
\t\t\t\t\t\t\t\t";
                }
                // line 359
                echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t\t";
            } elseif ((            // line 360
(isset($context["S_REGISTER_ENABLED"]) ? $context["S_REGISTER_ENABLED"] : null) &&  !((isset($context["S_SHOW_COPPA"]) ? $context["S_SHOW_COPPA"] : null) || (isset($context["S_REGISTRATION"]) ? $context["S_REGISTRATION"] : null)))) {
                echo " &nbsp;<a href=\"";
                echo (isset($context["U_REGISTER"]) ? $context["U_REGISTER"] : null);
                echo "\"> ";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("REGISTER");
                echo "</a>
\t\t\t\t\t\t\t";
            }
            // line 362
            echo "\t\t\t\t\t\t";
        }
        // line 363
        echo "\t\t\t\t\t</h5>
\t\t\t\t</td>
\t\t\t\t<td style=\"background:url(";
        // line 365
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/cu_m.png);\" width=\"20%\" height=\"45\" align=\"center\">
\t\t\t\t\t<h5>
\t\t\t\t\t\t";
        // line 367
        if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
            // line 368
            echo "\t\t\t\t\t\t\t<a href=\"";
            echo (isset($context["U_LOGIN_LOGOUT"]) ? $context["U_LOGIN_LOGOUT"] : null);
            echo "\"> ";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOGIN_LOGOUT");
            echo "</a>&nbsp;
\t\t\t\t\t\t";
        }
        // line 370
        echo "\t\t\t\t\t\t";
        if ((isset($context["U_RESTORE_PERMISSIONS"]) ? $context["U_RESTORE_PERMISSIONS"] : null)) {
            echo " &nbsp;<a href=\"";
            echo (isset($context["U_RESTORE_PERMISSIONS"]) ? $context["U_RESTORE_PERMISSIONS"] : null);
            echo "\"> ";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("RESTORE_PERMISSIONS");
            echo "</a>
\t\t\t\t\t\t";
        }
        // line 372
        echo "\t\t\t\t\t\t";
        if (((isset($context["S_BOARD_DISABLED"]) ? $context["S_BOARD_DISABLED"] : null) && (isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null))) {
            echo " &nbsp;<span style=\"color: red;\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("BOARD_DISABLED");
            echo "</span>
\t\t\t\t\t\t";
        }
        // line 374
        echo "\t\t\t\t\t</h5>
\t\t\t\t</td>
\t\t\t\t<td style=\"background:url(";
        // line 376
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/cu_m.png);\" width=\"20%\" height=\"45\" align=\"center\">
\t\t\t\t\t";
        // line 377
        if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
            // line 378
            echo "\t\t\t\t\t\t";
            if ((isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null)) {
                // line 379
                echo "\t\t\t\t\t\t\t<h5>
\t\t\t\t\t\t\t\t<a href=\"";
                // line 380
                echo (isset($context["U_PROFILE"]) ? $context["U_PROFILE"] : null);
                echo "\"> ";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("PROFILE");
                echo "</a>
\t\t\t\t\t\t\t</h5>
\t\t\t\t\t\t";
            }
            // line 383
            echo "\t\t\t\t\t";
        }
        // line 384
        echo "\t\t\t\t</td>
\t\t\t\t<td><img src=\"";
        // line 385
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/cu_r.png\" width=\"45\" height=\"45\" alt=\"\" /></td>
\t\t\t\t<td style=\"background:url(";
        // line 386
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_02.png) repeat;\" width=\"20%\" height=\"45\"></td>
\t\t\t\t<td><img src=\"";
        // line 387
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_03.png\" width=\"61\" height=\"45\" alt=\"\" /></td>
\t\t\t</tr>
\t\t\t</table>
\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t<td>
\t\t\t<table style=\"height:45\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t<tr>
\t\t\t\t<td><img src=\"";
        // line 396
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_08.png\" width=\"61\" height=\"45\" alt=\"\" /></td>
\t\t\t\t<td style=\"background:url(";
        // line 397
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_85.png);\" width=\"100%\" height=\"45\">
\t\t\t\t\t<table width=\"100%\" cellspacing=\"0\">
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t";
        // line 400
        if ((isset($context["S_DISPLAY_SEARCH"]) ? $context["S_DISPLAY_SEARCH"] : null)) {
            // line 401
            echo "\t\t\t\t\t\t\t\t<td style=\"background:url(";
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/p_menu/p_85.png);\" width=\"10%\" height=\"36\" align=\"center\">
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 402
            echo (isset($context["U_SEARCH_UNANSWERED"]) ? $context["U_SEARCH_UNANSWERED"] : null);
            echo "\"
\t\t\t\t\t\t\t\t\tonmouseover = \"rollover('search_unanswered')\"
\t\t\t\t\t\t\t\t\tonmouseout = \"rollout('search_unanswered')\"
\t\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 406
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/ut1.png\"
\t\t\t\t\t\t\t\t\tname=\"search_unanswered\"
\t\t\t\t\t\t\t\t\talt=\"";
            // line 408
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SEARCH_UNANSWERED");
            echo "\" border=\"0\"
\t\t\t\t\t\t\t\t\theight=\"36\" width=\"133\"
\t\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\tsetrollover(\"";
            // line 414
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/ut2.png\");
\t\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t<td style=\"background:url(";
            // line 418
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/p_menu/p_85.png);\" width=\"10%\" height=\"36\" align=\"center\">
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 419
            echo (isset($context["U_SEARCH_ACTIVE_TOPICS"]) ? $context["U_SEARCH_ACTIVE_TOPICS"] : null);
            echo "\"
\t\t\t\t\t\t\t\t\tonmouseover = \"rollover('search_active')\"
\t\t\t\t\t\t\t\t\tonmouseout = \"rollout('search_active')\"
\t\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 423
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/at1.png\"
\t\t\t\t\t\t\t\t\tname=\"search_active\"
\t\t\t\t\t\t\t\t\talt=\"";
            // line 425
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SEARCH_ACTIVE_TOPICS");
            echo "\" border=\"0\"
\t\t\t\t\t\t\t\t\theight=\"36\" width=\"133\"
\t\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\tsetrollover(\"";
            // line 431
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/at2.png\");
\t\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t<td style=\"background:url(";
            // line 435
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/p_menu/p_85.png);\" width=\"10%\" height=\"36\" align=\"center\">
\t\t\t\t\t\t\t\t\t&nbsp;
\t\t\t\t\t\t\t\t</td>

\t\t\t\t\t\t\t\t<td align=\"center\" width=\"40%\">
\t\t\t\t\t\t\t\t\t";
            // line 440
            if ((isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null)) {
                echo (isset($context["LAST_VISIT_DATE"]) ? $context["LAST_VISIT_DATE"] : null);
                echo "
\t\t\t\t\t\t\t\t\t";
            }
            // line 442
            echo "\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t";
            // line 443
            if (((isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null) || (isset($context["S_LOAD_UNREADS"]) ? $context["S_LOAD_UNREADS"] : null))) {
                // line 444
                echo "\t\t\t\t\t\t\t\t\t";
                if ((isset($context["S_LOAD_UNREADS"]) ? $context["S_LOAD_UNREADS"] : null)) {
                    // line 445
                    echo "\t\t\t\t\t\t\t\t\t\t<td style=\"background:url(";
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/p_menu/p_85.png);\" width=\"10%\" height=\"36\" align=\"center\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    // line 446
                    echo (isset($context["U_SEARCH_UNREAD"]) ? $context["U_SEARCH_UNREAD"] : null);
                    echo "\"
\t\t\t\t\t\t\t\t\t\t\tonmouseover = \"rollover('search_unread')\"
\t\t\t\t\t\t\t\t\t\t\tonmouseout = \"rollout('search_unread')\"
\t\t\t\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                    // line 450
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/buttons/ur1.png\"
\t\t\t\t\t\t\t\t\t\t\tname=\"search_unread\"
\t\t\t\t\t\t\t\t\t\t\talt=\"";
                    // line 452
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SEARCH_UNREAD");
                    echo "\" border=\"0\"
\t\t\t\t\t\t\t\t\t\t\theight=\"36\" width=\"133\"
\t\t\t\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\t\t\tsetrollover(\"";
                    // line 458
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/buttons/ur2.png\");
\t\t\t\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t";
                }
                // line 463
                echo "\t\t\t\t\t\t\t\t\t";
                if ((isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null)) {
                    // line 464
                    echo "\t\t\t\t\t\t\t\t\t\t<td style=\"background:url(";
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/p_menu/p_85.png);\" width=\"10%\" height=\"36\" align=\"center\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    // line 465
                    echo (isset($context["U_SEARCH_NEW"]) ? $context["U_SEARCH_NEW"] : null);
                    echo "\"
\t\t\t\t\t\t\t\t\t\t\tonmouseover = \"rollover('search_new')\"
\t\t\t\t\t\t\t\t\t\t\tonmouseout = \"rollout('search_new')\"
\t\t\t\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                    // line 469
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/buttons/np1.png\"
\t\t\t\t\t\t\t\t\t\t\tname=\"search_new\"
\t\t\t\t\t\t\t\t\t\t\talt=\"";
                    // line 471
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SEARCH_NEW");
                    echo "\" border=\"0\"
\t\t\t\t\t\t\t\t\t\t\theight=\"36\" width=\"133\"
\t\t\t\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\t\t\tsetrollover(\"";
                    // line 477
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/buttons/np2.png\");
\t\t\t\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t<td style=\"background:url(";
                    // line 481
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/p_menu/p_85.png);\" width=\"10%\" height=\"36\" align=\"center\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    // line 482
                    echo (isset($context["U_SEARCH_SELF"]) ? $context["U_SEARCH_SELF"] : null);
                    echo "\"
\t\t\t\t\t\t\t\t\t\t\tonmouseover = \"rollover('search_your')\"
\t\t\t\t\t\t\t\t\t\t\tonmouseout = \"rollout('search_your')\"
\t\t\t\t\t\t\t\t\t\t\t>
\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                    // line 486
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/buttons/yp1.png\"
\t\t\t\t\t\t\t\t\t\t\tname=\"search_your\"
\t\t\t\t\t\t\t\t\t\t\talt=\"";
                    // line 488
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SEARCH_SELF");
                    echo "\" border=\"0\"
\t\t\t\t\t\t\t\t\t\t\theight=\"36\" width=\"133\"
\t\t\t\t\t\t\t\t\t\t\t/>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\t\t\tsetrollover(\"";
                    // line 494
                    echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                    echo "/images/buttons/yp2.png\");
\t\t\t\t\t\t\t\t\t\t\t//-->
\t\t\t\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t";
                }
                // line 499
                echo "\t\t\t\t\t\t\t\t\t";
            }
            // line 500
            echo "\t\t\t\t\t\t\t";
        }
        // line 501
        echo "\t\t\t\t\t\t</tr>
\t\t\t\t\t</table>
\t\t\t\t</td>
\t\t\t\t<td><img src=\"";
        // line 504
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_09.png\" width=\"61\" height=\"45\" alt=\"\" /></td>
\t\t\t</tr>
\t\t\t</table>
\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t<td>
\t\t\t<table style=\"height:40;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t<tr>
\t\t\t\t<td><img src=\"";
        // line 513
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_10.png\" width=\"61\" height=\"40\" alt=\"\" /></td>
\t\t\t\t<td style=\"background:url(";
        // line 514
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_11.png) repeat;\" width=\"50%\" height=\"40\"></td>
\t\t\t\t<td style=\"background:url(";
        // line 515
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/clock.png);\" width=\"350\" height=\"40\">
\t\t\t\t\t<p class=\"gensmallclock\" align=\"center\">
\t\t\t\t\t\t<script type=\"text/javascript\" src=\"";
        // line 517
        echo (isset($context["T_TEMPLATE_PATH"]) ? $context["T_TEMPLATE_PATH"] : null);
        echo "/liveclock.js\">
\t\t\t\t\t\t</script>
\t\t\t\t\t</p>
\t\t\t\t</td>
\t\t\t\t<td style=\"background:url(";
        // line 521
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_11.png) repeat;\" width=\"20%\" height=\"40\"></td>
\t\t\t\t<td style=\"background:url(";
        // line 522
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_11.png) repeat;\" width=\"30%\" height=\"40\" align=\"right\">
\t\t\t\t\t";
        // line 523
        if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
            // line 524
            echo "\t\t\t\t\t\t<a href=\"";
            echo (isset($context["U_DELETE_COOKIES"]) ? $context["U_DELETE_COOKIES"] : null);
            echo "\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DELETE_COOKIES");
            echo "</a>
\t\t\t\t\t";
        }
        // line 526
        echo "\t\t\t\t</td>
\t\t\t\t<td><img src=\"";
        // line 527
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/p_menu/p_13.png\" width=\"61\" height=\"40\" alt=\"\" /></td>
\t\t\t</tr>
\t\t\t</table>
\t\t</td>
\t\t</tr>
\t</table>

";
        // line 534
        $location = "breadcrumbs.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("breadcrumbs.html", "overall_header.html", 534)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 535
        echo "
";
    }

    public function getTemplateName()
    {
        return "overall_header.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1059 => 535,  1047 => 534,  1037 => 527,  1034 => 526,  1026 => 524,  1024 => 523,  1020 => 522,  1016 => 521,  1009 => 517,  1004 => 515,  1000 => 514,  996 => 513,  984 => 504,  979 => 501,  976 => 500,  973 => 499,  965 => 494,  956 => 488,  951 => 486,  944 => 482,  940 => 481,  933 => 477,  924 => 471,  919 => 469,  912 => 465,  907 => 464,  904 => 463,  896 => 458,  887 => 452,  882 => 450,  875 => 446,  870 => 445,  867 => 444,  865 => 443,  862 => 442,  856 => 440,  848 => 435,  841 => 431,  832 => 425,  827 => 423,  820 => 419,  816 => 418,  809 => 414,  800 => 408,  795 => 406,  788 => 402,  783 => 401,  781 => 400,  775 => 397,  771 => 396,  759 => 387,  755 => 386,  751 => 385,  748 => 384,  745 => 383,  737 => 380,  734 => 379,  731 => 378,  729 => 377,  725 => 376,  721 => 374,  713 => 372,  703 => 370,  695 => 368,  693 => 367,  688 => 365,  684 => 363,  681 => 362,  672 => 360,  669 => 359,  665 => 357,  658 => 356,  649 => 355,  646 => 354,  644 => 353,  639 => 351,  635 => 350,  631 => 349,  627 => 348,  610 => 334,  606 => 333,  600 => 329,  597 => 328,  590 => 324,  579 => 316,  571 => 312,  568 => 311,  566 => 310,  562 => 308,  555 => 304,  544 => 296,  536 => 292,  534 => 291,  530 => 289,  523 => 285,  512 => 277,  504 => 273,  502 => 272,  494 => 267,  483 => 259,  476 => 255,  468 => 250,  457 => 242,  450 => 238,  443 => 234,  439 => 233,  435 => 232,  423 => 223,  419 => 222,  409 => 217,  403 => 216,  395 => 211,  391 => 210,  387 => 209,  375 => 200,  371 => 199,  367 => 198,  363 => 197,  359 => 196,  346 => 186,  302 => 144,  264 => 108,  262 => 107,  207 => 55,  203 => 54,  197 => 53,  181 => 39,  175 => 36,  169 => 34,  167 => 33,  159 => 28,  156 => 27,  138 => 25,  123 => 24,  112 => 23,  101 => 22,  90 => 21,  79 => 20,  68 => 19,  66 => 18,  52 => 16,  48 => 15,  36 => 6,  32 => 5,  22 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall_header.html", "");
    }
}
