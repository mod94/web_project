<?php

/* posting_buttons.html */
class __TwigTemplate_a324eff84174aef45f2b47cd253e7decb90eddc8ed826ac8912f7a5ef78afb5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<tr valign=\"middle\" align=\"";
        echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
        echo "\">
\t<td colspan=\"2\">
\t\t<script type=\"text/javascript\">
\t\t// <![CDATA[
\t\t
\t\t// Define the bbCode tags
\t\tvar bbcode = new Array();
\t\tvar bbtags = new Array('[b]','[/b]','[i]','[/i]','[u]','[/u]','[quote]','[/quote]','[code]','[/code]','[list]','[/list]','[list=]','[/list]','[img]','[/img]','[url]','[/url]','[flash=]', '[/flash]','[size=]','[/size]'";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "custom_tags", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["custom_tags"]) {
            echo ", ";
            echo $this->getAttribute($context["custom_tags"], "BBCODE_NAME", array());
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['custom_tags'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo ");
\t\tvar imageTag = false;
\t\t
\t\t// Helpline messages
\t\tvar help_line = {
\t\t\tb: '";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_B_HELP"), "js");
        echo "',
\t\t\ti: '";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_I_HELP"), "js");
        echo "',
\t\t\tu: '";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_U_HELP"), "js");
        echo "',
\t\t\tq: '";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_Q_HELP"), "js");
        echo "',
\t\t\tc: '";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_C_HELP"), "js");
        echo "',
\t\t\tl: '";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_L_HELP"), "js");
        echo "',
\t\t\to: '";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_O_HELP"), "js");
        echo "',
\t\t\tp: '";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_P_HELP"), "js");
        echo "',
\t\t\tw: '";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_W_HELP"), "js");
        echo "',
\t\t\ta: '";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_A_HELP"), "js");
        echo "',
\t\t\ts: '";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_S_HELP"), "js");
        echo "',
\t\t\tf: '";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_F_HELP"), "js");
        echo "',
\t\t\te: '";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_E_HELP"), "js");
        echo "',
\t\t\td: '";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_D_HELP"), "js");
        echo "',
\t\t\tt: '";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("BBCODE_T_HELP"), "js");
        echo "',
\t\t\ttip: '";
        // line 28
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("STYLES_TIP");
        echo "'
\t\t\t";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "custom_tags", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["custom_tags"]) {
            // line 30
            echo "\t\t\t\t,cb_";
            echo $this->getAttribute($context["custom_tags"], "BBCODE_ID", array());
            echo ": '";
            echo $this->getAttribute($context["custom_tags"], "A_BBCODE_HELPLINE", array());
            echo "'
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['custom_tags'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "\t\t}

\t\t// ]]>
\t\t</script>
\t\t<script type=\"text/javascript\" src=\"";
        // line 36
        echo (isset($context["T_TEMPLATE_PATH"]) ? $context["T_TEMPLATE_PATH"] : null);
        echo "/editor.js\"></script>

";
        // line 38
        if ((isset($context["S_BBCODE_ALLOWED"]) ? $context["S_BBCODE_ALLOWED"] : null)) {
            // line 39
            echo "\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"b\" name=\"addbbcode0\" value=\" B \" style=\"font-weight:bold; width: 30px;\" onclick=\"bbstyle(0)\" onmouseover=\"helpline('b')\" onmouseout=\"helpline('tip')\" />
\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"i\" name=\"addbbcode2\" value=\" i \" style=\"font-style:italic; width: 30px;\" onclick=\"bbstyle(2)\" onmouseover=\"helpline('i')\" onmouseout=\"helpline('tip')\" />
\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"u\" name=\"addbbcode4\" value=\" u \" style=\"text-decoration: underline; width: 30px;\" onclick=\"bbstyle(4)\" onmouseover=\"helpline('u')\" onmouseout=\"helpline('tip')\" />
\t\t";
            // line 42
            if ((isset($context["S_BBCODE_QUOTE"]) ? $context["S_BBCODE_QUOTE"] : null)) {
                // line 43
                echo "\t\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"q\" name=\"addbbcode6\" value=\"Quote\" style=\"width: 50px\" onclick=\"bbstyle(6)\" onmouseover=\"helpline('q')\" onmouseout=\"helpline('tip')\" />
\t\t";
            }
            // line 45
            echo "\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"c\" name=\"addbbcode8\" value=\"Code\" style=\"width: 40px\" onclick=\"bbstyle(8)\" onmouseover=\"helpline('c')\" onmouseout=\"helpline('tip')\" />
\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"l\" name=\"addbbcode10\" value=\"List\" style=\"width: 40px\" onclick=\"bbstyle(10)\" onmouseover=\"helpline('l')\" onmouseout=\"helpline('tip')\" />
\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"o\" name=\"addbbcode12\" value=\"List=\" style=\"width: 40px\" onclick=\"bbstyle(12)\" onmouseover=\"helpline('o')\" onmouseout=\"helpline('tip')\" />
\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"y\" name=\"addlitsitem\" value=\"[*]\" style=\"width: 40px\" onclick=\"bbstyle(-1)\" onmouseover=\"helpline('e')\" onmouseout=\"helpline('tip')\" />
\t\t";
            // line 49
            if ((isset($context["S_BBCODE_IMG"]) ? $context["S_BBCODE_IMG"] : null)) {
                // line 50
                echo "\t\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"p\" name=\"addbbcode14\" value=\"Img\" style=\"width: 40px\" onclick=\"bbstyle(14)\" onmouseover=\"helpline('p')\" onmouseout=\"helpline('tip')\" />
\t\t";
            }
            // line 52
            echo "\t\t";
            if ((isset($context["S_LINKS_ALLOWED"]) ? $context["S_LINKS_ALLOWED"] : null)) {
                // line 53
                echo "\t\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"w\" name=\"addbbcode16\" value=\"URL\" style=\"text-decoration: underline; width: 40px\" onclick=\"bbstyle(16)\" onmouseover=\"helpline('w')\" onmouseout=\"helpline('tip')\" />
\t\t";
            }
            // line 55
            echo "\t\t";
            if ((isset($context["S_BBCODE_FLASH"]) ? $context["S_BBCODE_FLASH"] : null)) {
                // line 56
                echo "\t\t\t<input type=\"button\" class=\"btnbbcode\" accesskey=\"d\" name=\"addbbcode18\" value=\"Flash\" onclick=\"bbstyle(18)\" onmouseover=\"helpline('d')\" onmouseout=\"helpline('tip')\" />
\t\t";
            }
            // line 58
            echo "\t\t<span class=\"genmed nowrap\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FONT_SIZE");
            echo ": <select class=\"gensmalleditor\" name=\"addbbcode20\" onchange=\"bbfontstyle('[size=' + this.form.addbbcode20.options[this.form.addbbcode20.selectedIndex].value + ']', '[/size]');this.form.addbbcode20.selectedIndex = 2;\" onmouseover=\"helpline('f')\" onmouseout=\"helpline('tip')\">
\t\t\t<option value=\"50\">";
            // line 59
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FONT_TINY");
            echo "</option>
\t\t\t<option value=\"85\">";
            // line 60
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FONT_SMALL");
            echo "</option>
\t\t\t<option value=\"100\" selected=\"selected\">";
            // line 61
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FONT_NORMAL");
            echo "</option>
\t\t\t";
            // line 62
            if (( !(isset($context["MAX_FONT_SIZE"]) ? $context["MAX_FONT_SIZE"] : null) || ((isset($context["MAX_FONT_SIZE"]) ? $context["MAX_FONT_SIZE"] : null) >= 150))) {
                // line 63
                echo "\t\t\t<option value=\"150\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FONT_LARGE");
                echo "</option>
\t\t\t";
                // line 64
                if (( !(isset($context["MAX_FONT_SIZE"]) ? $context["MAX_FONT_SIZE"] : null) || ((isset($context["MAX_FONT_SIZE"]) ? $context["MAX_FONT_SIZE"] : null) >= 200))) {
                    // line 65
                    echo "\t\t\t<option value=\"200\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FONT_HUGE");
                    echo "</option>
\t\t\t";
                }
                // line 67
                echo "\t\t\t";
            }
            // line 68
            echo "\t\t</select></span>
\t\t<span class=\"genmed nowrap\"><select class=\"gensmalleditor\" name=\"addbbcodefont\" onchange=\"bbfontstyle('[font=' + this.form.addbbcodefont.options[this.form.addbbcodefont.selectedIndex].value + ']', '[/font]');this.form.addbbcodefont.selectedIndex = 6;\" title=\"Font style: [font=Tahoma]text[/font]\">
      <option style=\"font-family: Tahoma;\" value=\"Tahoma\">Tahoma</option>
      <option style=\"font-family: Verdana;\" value=\"Verdana\">Verdana</option>
      <option style=\"font-family: Arial Black;\" value=\"Arial Black\">Arial Black</option>
      <option style=\"font-family: Comic Sans MS;\" value=\"Comic Sans MS\">Comic Sans MS</option>
      <option style=\"font-family: Lucida Console;\" value=\"Lucida Console\">Lucida Console</option>
      <option style=\"font-family: Palatino Linotype;\" value=\"Palatino Linotype\">Palatino Linotype</option>
      <option value=\"\" selected=\"selected\">Font Family</option>
      <option style=\"font-family: MS Sans Serif4;\" value=\"MS Sans Serif4\">MS Sans Serif4</option>
      <option style=\"font-family: System;\" value=\"System\">System</option>
      <option style=\"font-family: Georgia1;\" value=\"Georgia1\">Georgia1</option>
      <option style=\"font-family: Impact;\" value=\"Impact\">Impact</option>
      <option style=\"font-family: Courier;\" value=\"Courier\">Courier</option>
      <option style=\"font-family: Symbol;\" value=\"Symbol\">Symbol</option>
   </select></span>
";
        }
        // line 85
        echo "\t</td>
</tr>
";
        // line 87
        if (((isset($context["S_BBCODE_ALLOWED"]) ? $context["S_BBCODE_ALLOWED"] : null) && twig_length_filter($this->env, $this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "custom_tags", array())))) {
            // line 88
            echo "\t<tr valign=\"middle\" align=\"";
            echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
            echo "\">
\t\t<td colspan=\"2\">
\t\t";
            // line 90
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "custom_tags", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["custom_tags"]) {
                // line 91
                echo "\t\t\t<input type=\"button\" class=\"btnbbcode\" name=\"addbbcode";
                echo $this->getAttribute($context["custom_tags"], "BBCODE_ID", array());
                echo "\" value=\"";
                echo $this->getAttribute($context["custom_tags"], "BBCODE_TAG", array());
                echo "\" onclick=\"bbstyle(";
                echo $this->getAttribute($context["custom_tags"], "BBCODE_ID", array());
                echo ")\"";
                if (($this->getAttribute($context["custom_tags"], "BBCODE_HELPLINE", array()) !== "")) {
                    echo " onmouseover=\"helpline('cb_";
                    echo $this->getAttribute($context["custom_tags"], "BBCODE_ID", array());
                    echo "')\" onmouseout=\"helpline('tip')\"";
                }
                echo " />
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['custom_tags'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 93
            echo "\t\t</td>
\t</tr>
";
        }
        // line 96
        if ((isset($context["S_BBCODE_ALLOWED"]) ? $context["S_BBCODE_ALLOWED"] : null)) {
            // line 97
            echo "<tr>
\t<td";
            // line 98
            if (($this->getAttribute((isset($context["definition"]) ? $context["definition"] : null), "S_SIGNATURE", array()) || (isset($context["S_EDIT_DRAFT"]) ? $context["S_EDIT_DRAFT"] : null))) {
                echo " colspan=\"2\"";
            }
            echo "><input type=\"text\" readonly=\"readonly\" name=\"helpbox\" style=\"width:100%\" class=\"helpline\" value=\"";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("STYLES_TIP");
            echo "\" /></td>
\t";
            // line 99
            if (( !$this->getAttribute((isset($context["definition"]) ? $context["definition"] : null), "S_SIGNATURE", array()) &&  !(isset($context["S_EDIT_DRAFT"]) ? $context["S_EDIT_DRAFT"] : null))) {
                // line 100
                echo "\t\t<td class=\"genmed\" align=\"center\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FONT_COLOR");
                echo "</td>
\t";
            }
            // line 102
            echo "</tr>
";
        }
    }

    public function getTemplateName()
    {
        return "posting_buttons.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  290 => 102,  284 => 100,  282 => 99,  274 => 98,  271 => 97,  269 => 96,  264 => 93,  245 => 91,  241 => 90,  235 => 88,  233 => 87,  229 => 85,  210 => 68,  207 => 67,  201 => 65,  199 => 64,  194 => 63,  192 => 62,  188 => 61,  184 => 60,  180 => 59,  175 => 58,  171 => 56,  168 => 55,  164 => 53,  161 => 52,  157 => 50,  155 => 49,  149 => 45,  145 => 43,  143 => 42,  138 => 39,  136 => 38,  131 => 36,  125 => 32,  114 => 30,  110 => 29,  106 => 28,  102 => 27,  98 => 26,  94 => 25,  90 => 24,  86 => 23,  82 => 22,  78 => 21,  74 => 20,  70 => 19,  66 => 18,  62 => 17,  58 => 16,  54 => 15,  50 => 14,  46 => 13,  30 => 8,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "posting_buttons.html", "");
    }
}
