<?php

/* index_body.html */
class __TwigTemplate_95724628641bfdd3c7dd7e388a259d4518483318654e29c5868a371b613f214a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $location = "overall_header.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("overall_header.html", "index_body.html", 1)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 2
        if ((isset($context["U_MCP"]) ? $context["U_MCP"] : null)) {
            // line 3
            echo "
\t<div id=\"pageheader\">
<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t<tr>
\t<td>
\t\t<p class=\"linkmcp\"> 


<a href=\"";
            // line 11
            echo (isset($context["U_MCP"]) ? $context["U_MCP"] : null);
            echo "\"
   onmouseover = \"rollover('mod')\" 
   onmouseout  = \"rollout('mod')\" 
   ><img 
   src=\"";
            // line 15
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/mod1.png\" 
   name=\"mod\" 
   alt=\"Moderator\" border=\"0\"
   height=\"45\" width=\"188\"
   /></a>
<script type=\"text/javascript\">
<!--
setrollover(\"";
            // line 22
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/mod2.png\");
//-->
</script>


</p>
</td>
</tr>
</table>
\t</div>
";
        }
        // line 33
        echo "
<div id=\"pagecontent\">
";
        // line 35
        $location = "forumlist_body.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("forumlist_body.html", "index_body.html", 35)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 36
        echo "</div>

\t\t";
        // line 38
        $location = "breadcrumbs.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("breadcrumbs.html", "index_body.html", 38)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 39
        echo "

<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t<tr>
\t\t<td>
\t\t\t<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t<tr>
\t\t\t\t\t<td><img src=\"";
        // line 46
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t<td style=\"background:url(";
        // line 47
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\"></td>
\t\t\t\t\t<td style=\"background:url(";
        // line 48
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/cu.png) repeat;\" width=\"300\" height=\"48\"><h4 align=\"center\">Board Statistics</h4></td>
\t\t\t\t\t<td style=\"background:url(";
        // line 49
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\"></td>
\t\t\t\t\t<td><img src=\"";
        // line 50
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t</tr>
\t\t\t</table>

\t\t\t<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t<tr>
\t\t\t\t\t<td style=\"background:url(";
        // line 56
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_08.png) repeat;\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t<td>

\t\t\t\t";
        // line 59
        if ((isset($context["S_DISPLAY_ONLINE_LIST"]) ? $context["S_DISPLAY_ONLINE_LIST"] : null)) {
            // line 60
            echo "
\t\t\t\t\t\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td class=\"cat\" colspan=\"2\">";
            // line 63
            if ((isset($context["U_VIEWONLINE"]) ? $context["U_VIEWONLINE"] : null)) {
                echo "<h4><a href=\"";
                echo (isset($context["U_VIEWONLINE"]) ? $context["U_VIEWONLINE"] : null);
                echo "\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("WHO_IS_ONLINE");
                echo "</a></h4>";
            } else {
                echo "<h4>";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("WHO_IS_ONLINE");
                echo "</h4>";
            }
            echo "</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t";
            // line 66
            if ((isset($context["LEGEND"]) ? $context["LEGEND"] : null)) {
                // line 67
                echo "\t\t\t\t\t\t\t\t<td class=\"row1\" rowspan=\"2\" align=\"center\" valign=\"middle\"><img src=\"";
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/online.png\" alt=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("WHO_IS_ONLINE");
                echo "\" /></td>
\t\t\t\t\t\t\t";
            } else {
                // line 69
                echo "\t\t\t\t\t\t\t\t<td class=\"row1\" align=\"center\" valign=\"middle\"><img src=\"";
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/whosonline.gif\" alt=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("WHO_IS_ONLINE");
                echo "\" /></td>
\t\t\t\t\t\t\t";
            }
            // line 71
            echo "\t\t\t\t\t\t\t\t<td class=\"row1\" width=\"100%\"><span class=\"genmed\">";
            echo (isset($context["TOTAL_USERS_ONLINE"]) ? $context["TOTAL_USERS_ONLINE"] : null);
            echo " (";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ONLINE_EXPLAIN");
            echo ")<br />";
            echo (isset($context["RECORD_USERS"]) ? $context["RECORD_USERS"] : null);
            echo "<br /><br />";
            echo (isset($context["LOGGED_IN_USER_LIST"]) ? $context["LOGGED_IN_USER_LIST"] : null);
            echo "</span></td>\t</tr>
\t\t\t\t\t\t\t";
            // line 72
            if ((isset($context["LEGEND"]) ? $context["LEGEND"] : null)) {
                // line 73
                echo "\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td class=\"row1\"><b class=\"gensmall\">";
                // line 74
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LEGEND");
                echo " :: ";
                echo (isset($context["LEGEND"]) ? $context["LEGEND"] : null);
                echo "</b></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t";
            }
            // line 77
            echo "\t\t\t\t\t\t</table>
\t\t\t\t";
        }
        // line 79
        echo "
\t\t\t\t";
        // line 80
        if ((isset($context["S_DISPLAY_BIRTHDAY_LIST"]) ? $context["S_DISPLAY_BIRTHDAY_LIST"] : null)) {
            // line 81
            echo "
\t\t\t\t\t\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td class=\"cat\" colspan=\"2\"><h4>";
            // line 84
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("BIRTHDAYS");
            echo "</h4></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td class=\"row1\" width=\"38\" align=\"left\" valign=\"middle\"><img src=\"";
            // line 87
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/birthday.png\" width=\"38\" height=\"38\" alt=\"\" /></td>
\t\t\t\t\t\t\t\t<td class=\"row1\" width=\"100%\"><p class=\"genmed\">";
            // line 88
            if ((isset($context["BIRTHDAY_LIST"]) ? $context["BIRTHDAY_LIST"] : null)) {
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CONGRATULATIONS");
                echo ": <b>";
                echo (isset($context["BIRTHDAY_LIST"]) ? $context["BIRTHDAY_LIST"] : null);
                echo "</b>";
            } else {
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_BIRTHDAYS");
            }
            echo "</p></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</table>
\t\t\t\t";
        }
        // line 92
        echo "\t\t\t\t\t\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td class=\"cat\" colspan=\"2\"><h4>";
        // line 94
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("STATISTICS");
        echo "</h4></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td class=\"row1\"><img src=\"";
        // line 97
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/stats.png\" alt=\"";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("STATISTICS");
        echo "\" /></td>
\t\t\t\t\t\t\t\t<td class=\"row1\" width=\"100%\" valign=\"middle\"><p class=\"genmed\">";
        // line 98
        echo (isset($context["TOTAL_POSTS"]) ? $context["TOTAL_POSTS"] : null);
        echo " | ";
        echo (isset($context["TOTAL_TOPICS"]) ? $context["TOTAL_TOPICS"] : null);
        echo " | ";
        echo (isset($context["TOTAL_USERS"]) ? $context["TOTAL_USERS"] : null);
        echo " | ";
        echo (isset($context["NEWEST_USER"]) ? $context["NEWEST_USER"] : null);
        echo "</p></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</table>
\t\t\t\t\t</td>
\t\t\t\t\t<td style=\"background:url(";
        // line 102
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_09.png) repeat;\" width=\"41\" height=\"100%\"></td>
\t\t\t\t</tr>
\t\t\t</table>

\t\t\t<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t<tr>

\t\t\t\t\t<td><img src=\"";
        // line 109
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t<td style=\"background:url(";
        // line 110
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_11.png) repeat;\" width=\"100%\" height=\"46\"></td>
\t\t\t\t\t<td><img src=\"";
        // line 111
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t</tr>
\t\t\t</table>
\t\t</td>
\t</tr>
</table>


";
        // line 119
        if (( !(isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null) &&  !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null))) {
            // line 120
            echo "\t<br clear=\"all\" />

\t<form method=\"post\" action=\"";
            // line 122
            echo (isset($context["S_LOGIN_ACTION"]) ? $context["S_LOGIN_ACTION"] : null);
            echo "\">

<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t<tr>
\t\t<td>
\t\t\t<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t<tr>
\t\t\t\t\t<td><img src=\"";
            // line 129
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t<td style=\"background:url(";
            // line 130
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\"></td>
\t\t\t\t\t<td style=\"background:url(";
            // line 131
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/cu.png) repeat;\" width=\"350\" height=\"48\">
\t\t\t\t\t<h4 align=\"center\"><a href=\"";
            // line 132
            echo (isset($context["U_LOGIN_LOGOUT"]) ? $context["U_LOGIN_LOGOUT"] : null);
            echo "\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOGIN_LOGOUT");
            echo "</a></h4></td>
\t\t\t\t\t<td style=\"background:url(";
            // line 133
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_02.png) repeat;\" width=\"50%\" height=\"48\"></td>
\t\t\t\t\t<td><img src=\"";
            // line 134
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t</tr>
\t\t\t</table>
\t\t\t<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t<tr>
\t\t\t\t\t<td style=\"background:url(";
            // line 139
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_08.png) repeat;\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t<td>\t
\t\t\t\t\t\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td class=\"row1\" align=\"center\"><span class=\"genmed\">";
            // line 143
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("USERNAME");
            echo ":</span> <input class=\"post\" type=\"text\" name=\"username\" size=\"10\" />&nbsp; <span class=\"genmed\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("PASSWORD");
            echo ":</span> <input class=\"post\" type=\"password\" name=\"password\" size=\"10\" />&nbsp; ";
            if ((isset($context["S_AUTOLOGIN_ENABLED"]) ? $context["S_AUTOLOGIN_ENABLED"] : null)) {
                echo " <span class=\"gensmall\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOG_ME_IN");
                echo "</span> <input type=\"checkbox\" class=\"radio\" name=\"autologin\" />";
            }
            echo "&nbsp; <input type=\"submit\" class=\"btnmain\" name=\"login\" value=\"";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOGIN");
            echo "\" /></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</table>
\t\t\t\t\t\t";
            // line 146
            echo (isset($context["S_LOGIN_REDIRECT"]) ? $context["S_LOGIN_REDIRECT"] : null);
            echo "
\t\t\t\t\t</td>
\t\t\t\t\t<td style=\"background:url(";
            // line 148
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_09.png) repeat;\" width=\"41\" height=\"100%\"></td>
\t\t\t\t</tr>
\t\t\t\t<tr>
\t\t\t\t\t<td><img src=\"";
            // line 151
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\"/></td>
\t\t\t\t\t<td style=\"background:url(";
            // line 152
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_11.png) repeat;\" width=\"100%\" height=\"46\"></td>
\t\t\t\t\t<td><img src=\"";
            // line 153
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t</tr>
\t\t\t</table>
\t\t</td>
\t</tr>
</table>
\t";
            // line 159
            echo (isset($context["S_FORM_TOKEN"]) ? $context["S_FORM_TOKEN"] : null);
            echo "
\t</form>
";
        }
        // line 162
        echo "

<table class=\"legend\">
\t<tr>
\t\t<td width=\"20\" align=\"center\">";
        // line 166
        echo (isset($context["FORUM_UNREAD_IMG"]) ? $context["FORUM_UNREAD_IMG"] : null);
        echo "</td>
\t\t<td><span class=\"gensmall\">";
        // line 167
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("UNREAD_POSTS");
        echo "</span></td>
\t\t<td>&nbsp;&nbsp;</td>
\t\t<td width=\"20\" align=\"center\">";
        // line 169
        echo (isset($context["FORUM_IMG"]) ? $context["FORUM_IMG"] : null);
        echo "</td>
\t\t<td><span class=\"gensmall\">";
        // line 170
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_UNREAD_POSTS");
        echo "</span></td>
\t\t<td>&nbsp;&nbsp;</td>
\t\t<td width=\"20\" align=\"center\">";
        // line 172
        echo (isset($context["FORUM_LOCKED_IMG"]) ? $context["FORUM_LOCKED_IMG"] : null);
        echo "</td>
\t\t<td><span class=\"gensmall\">";
        // line 173
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM_LOCKED");
        echo "</span></td>
\t</tr>
</table>



";
        // line 179
        $location = "overall_footer.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("overall_footer.html", "index_body.html", 179)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
    }

    public function getTemplateName()
    {
        return "index_body.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  447 => 179,  438 => 173,  434 => 172,  429 => 170,  425 => 169,  420 => 167,  416 => 166,  410 => 162,  404 => 159,  395 => 153,  391 => 152,  387 => 151,  381 => 148,  376 => 146,  360 => 143,  353 => 139,  345 => 134,  341 => 133,  335 => 132,  331 => 131,  327 => 130,  323 => 129,  313 => 122,  309 => 120,  307 => 119,  296 => 111,  292 => 110,  288 => 109,  278 => 102,  265 => 98,  259 => 97,  253 => 94,  249 => 92,  235 => 88,  231 => 87,  225 => 84,  220 => 81,  218 => 80,  215 => 79,  211 => 77,  203 => 74,  200 => 73,  198 => 72,  187 => 71,  179 => 69,  171 => 67,  169 => 66,  153 => 63,  148 => 60,  146 => 59,  140 => 56,  131 => 50,  127 => 49,  123 => 48,  119 => 47,  115 => 46,  106 => 39,  94 => 38,  90 => 36,  78 => 35,  74 => 33,  60 => 22,  50 => 15,  43 => 11,  33 => 3,  31 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "index_body.html", "");
    }
}
