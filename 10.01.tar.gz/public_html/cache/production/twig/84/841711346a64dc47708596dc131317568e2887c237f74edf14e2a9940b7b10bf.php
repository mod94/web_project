<?php

/* posting_poll_body.html */
class __TwigTemplate_c90aaba868feefa296d0eb22c8fc07367697db6f3b72b9a516ae063c6b450cdb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
<tr>
\t<th colspan=\"2\">";
        // line 3
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ADD_POLL");
        echo "</th>
</tr>
<tr>
\t<td class=\"row3\" colspan=\"2\"><span class=\"gensmall\">";
        // line 6
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ADD_POLL_EXPLAIN");
        echo "</span></td>
</tr>
<tr>
\t<td class=\"row1\"><b class=\"genmed\">";
        // line 9
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_QUESTION");
        echo ":</b></td>
\t<td class=\"row2\"><input class=\"post\" type=\"text\" name=\"poll_title\" size=\"50\" maxlength=\"255\" value=\"";
        // line 10
        echo (isset($context["POLL_TITLE"]) ? $context["POLL_TITLE"] : null);
        echo "\" /></td>
</tr>
<tr>
\t<td class=\"row1\"><b class=\"genmed\">";
        // line 13
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_OPTIONS");
        echo ":</b><br /><span class=\"gensmall\">";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_OPTIONS_EXPLAIN");
        echo "</span></td>
\t<td class=\"row2\"><textarea style=\"width:450px\" name=\"poll_option_text\" rows=\"5\" cols=\"35\">";
        // line 14
        echo (isset($context["POLL_OPTIONS"]) ? $context["POLL_OPTIONS"] : null);
        echo "</textarea></td>
</tr>
<tr>
\t<td class=\"row1\"><b class=\"genmed\">";
        // line 17
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_MAX_OPTIONS");
        echo ":</b><br /><span class=\"gensmall\">";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_MAX_OPTIONS_EXPLAIN");
        echo "</span></td>
\t<td class=\"row2\"><input class=\"post\" type=\"text\" name=\"poll_max_options\" size=\"3\" maxlength=\"3\" value=\"";
        // line 18
        echo (isset($context["POLL_MAX_OPTIONS"]) ? $context["POLL_MAX_OPTIONS"] : null);
        echo "\" /></td>
</tr>
<tr>
\t<td class=\"row1\"><b class=\"genmed\">";
        // line 21
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_FOR");
        echo ":</b></td>
\t<td class=\"row2\"><input class=\"post\" type=\"text\" name=\"poll_length\" size=\"3\" maxlength=\"3\" value=\"";
        // line 22
        echo (isset($context["POLL_LENGTH"]) ? $context["POLL_LENGTH"] : null);
        echo "\" />&nbsp;<b class=\"gen\">";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DAYS");
        echo "</b> <span class=\"gensmall\">";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_FOR_EXPLAIN");
        echo "</span></td>
</tr>
";
        // line 24
        if ((isset($context["S_POLL_VOTE_CHANGE"]) ? $context["S_POLL_VOTE_CHANGE"] : null)) {
            // line 25
            echo "\t<tr>
\t\t<td class=\"row1\"><b class=\"genmed\">";
            // line 26
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_VOTE_CHANGE");
            echo ":</b><br /><span class=\"gensmall\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_VOTE_CHANGE_EXPLAIN");
            echo "</span></td>
\t\t<td class=\"row2\"><input type=\"checkbox\" class=\"radio\" name=\"poll_vote_change\"";
            // line 27
            echo (isset($context["VOTE_CHANGE_CHECKED"]) ? $context["VOTE_CHANGE_CHECKED"] : null);
            echo " /></td>
\t</tr>
";
        }
        // line 30
        echo "
";
        // line 31
        if ((isset($context["S_POLL_DELETE"]) ? $context["S_POLL_DELETE"] : null)) {
            // line 32
            echo "\t<tr>
\t\t<td class=\"row1\"><b class=\"genmed\">";
            // line 33
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_DELETE");
            echo ":</b></td>
\t\t<td class=\"row2\"><input type=\"checkbox\" class=\"radio\" name=\"poll_delete\"";
            // line 34
            if ((isset($context["S_POLL_DELETE_CHECKED"]) ? $context["S_POLL_DELETE_CHECKED"] : null)) {
                echo " checked=\"checked\"";
            }
            echo " /></td>
\t</tr>
";
        }
    }

    public function getTemplateName()
    {
        return "posting_poll_body.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 34,  107 => 33,  104 => 32,  102 => 31,  99 => 30,  93 => 27,  87 => 26,  84 => 25,  82 => 24,  73 => 22,  69 => 21,  63 => 18,  57 => 17,  51 => 14,  45 => 13,  39 => 10,  35 => 9,  29 => 6,  23 => 3,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "posting_poll_body.html", "");
    }
}
