<?php

/* breadcrumbs.html */
class __TwigTemplate_23a06e2c3f3ca64c0e899ebcf5e0f172178662990a58d023d2ee11d93d358653 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t
\t\t<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" style=\"margin-top: 5px;\">
\t\t\t<tr>
\t\t\t\t<td><img src=\"";
        // line 4
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/nav01.png\" width=\"46\" height=\"55\" alt=\"\" /></td>
\t\t\t\t<td width=\"100%\" style=\"background:url(";
        // line 5
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/nav02.png) repeat;\" height=\"55\">
\t\t\t\t<p class=\"breadcrumbs\"><a href=\"";
        // line 6
        echo (isset($context["U_INDEX"]) ? $context["U_INDEX"] : null);
        echo "\">";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("INDEX");
        echo "</a>";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "navlinks", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["navlinks"]) {
            echo " &#187; <a href=\"";
            echo $this->getAttribute($context["navlinks"], "U_VIEW_FORUM", array());
            echo "\">";
            echo $this->getAttribute($context["navlinks"], "FORUM_NAME", array());
            echo "</a>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['navlinks'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</p>
\t\t\t\t<p class=\"datetime\">";
        // line 7
        echo (isset($context["S_TIMEZONE"]) ? $context["S_TIMEZONE"] : null);
        echo "</p>
\t\t\t\t</td>
\t\t\t\t<td><img src=\"";
        // line 9
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/nav03.png\" width=\"46\" height=\"55\" alt=\"\" /></td>
\t\t\t</tr>
\t\t</table>
";
    }

    public function getTemplateName()
    {
        return "breadcrumbs.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 9,  51 => 7,  32 => 6,  28 => 5,  24 => 4,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "breadcrumbs.html", "");
    }
}
