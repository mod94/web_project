<?php

/* posting_body.html */
class __TwigTemplate_b527dde628b78afb8d70909e357767cf8419fdc3d5542c34c9bd12eaec54731d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ((isset($context["S_PRIVMSGS"]) ? $context["S_PRIVMSGS"] : null)) {
            // line 2
            echo "\t";
            $location = "ucp_header.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("ucp_header.html", "posting_body.html", 2)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        } else {
            // line 4
            echo "\t";
            $location = "overall_header.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("overall_header.html", "posting_body.html", 4)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        }
        // line 6
        echo "
";
        // line 7
        if ((isset($context["S_FORUM_RULES"]) ? $context["S_FORUM_RULES"] : null)) {
            // line 8
            if ((isset($context["U_FORUM_RULES"]) ? $context["U_FORUM_RULES"] : null)) {
                // line 9
                echo "\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 11
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_001.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 12
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_002.png) repeat;\" width=\"50%\" height=\"34\"></td>
\t\t\t<td style=\"background:url(";
                // line 13
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/cu0.png);\" width=\"350\" height=\"34\"><h3 align=\"center\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM_RULES");
                echo "</h3></td>
\t\t\t<td style=\"background:url(";
                // line 14
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_002.png) repeat;\" width=\"50%\" height=\"34\"></td>
\t\t\t<td><img src=\"";
                // line 15
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_004.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t</tr>
\t</table>
\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td style=\"background:url(";
                // line 20
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_008.png)\" width=\"34\" height=\"100%\"></td>
\t\t\t<td>  
\t\t\t\t<div class=\"forumrules\">
\t\t\t\t<a href=\"";
                // line 23
                echo (isset($context["U_FORUM_RULES"]) ? $context["U_FORUM_RULES"] : null);
                echo "\"><b>";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM_RULES_LINK");
                echo "</b></a>
\t\t\t\t</div>
\t\t\t</td>
\t\t\t<td style=\"background:url(";
                // line 26
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_009.png)\" width=\"28\" height=\"100%\"></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 29
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_010.png\" width=\"28\" height=\"32\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 30
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_011.png)\" width=\"100%\" height=\"32\"></td>
\t\t\t<td><img src=\"";
                // line 31
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_013.png\" width=\"28\" height=\"32\" alt=\"\" /></td>
\t\t</tr>
\t</table>  
\t";
            } else {
                // line 35
                echo "\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 37
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_001.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 38
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_002.png)\" width=\"50%\" height=\"34\"></td>
\t\t\t<td style=\"background:url(";
                // line 39
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/cu0.png)\" width=\"350\" height=\"34\"><h3 align=\"center\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM_RULES");
                echo "</h3></td>
\t\t\t<td style=\"background:url(";
                // line 40
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_002.png)\" width=\"50%\" height=\"34\"></td>
\t\t\t<td><img src=\"";
                // line 41
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_004.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t</tr>
\t</table>
\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td style=\"background:url(";
                // line 46
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_008.png)\" width=\"34\" height=\"100%\"></td>
\t\t\t<td>
\t\t\t\t<div class=\"forumrules\">
\t\t\t\t";
                // line 49
                echo (isset($context["FORUM_RULES"]) ? $context["FORUM_RULES"] : null);
                echo "
\t\t\t\t</div>
\t\t\t</td>
\t\t\t<td style=\"background:url(";
                // line 52
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_009.png)\" width=\"28\" height=\"100%\"></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 55
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_010.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 56
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_011.png)\" width=\"100%\" height=\"34\"></td>
\t\t\t<td><img src=\"";
                // line 57
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_013.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t</tr>
\t</table>
";
            }
            // line 61
            echo "<br clear=\"all\" />
";
        }
        // line 63
        echo "
";
        // line 64
        if ( !(isset($context["S_PRIVMSGS"]) ? $context["S_PRIVMSGS"] : null)) {
            // line 65
            echo "\t<div id=\"pageheader\">
\t\t<h2>";
            // line 66
            if ((isset($context["TOPIC_TITLE"]) ? $context["TOPIC_TITLE"] : null)) {
                echo "<a class=\"titles\" href=\"";
                echo (isset($context["U_VIEW_TOPIC"]) ? $context["U_VIEW_TOPIC"] : null);
                echo "\">";
                echo (isset($context["TOPIC_TITLE"]) ? $context["TOPIC_TITLE"] : null);
                echo "</a>";
            } else {
                echo "<a class=\"titles\" href=\"";
                echo (isset($context["U_VIEW_FORUM"]) ? $context["U_VIEW_FORUM"] : null);
                echo "\">";
                echo (isset($context["FORUM_NAME"]) ? $context["FORUM_NAME"] : null);
                echo "</a>";
            }
            echo "</h2>
\t\t";
            // line 67
            if ((isset($context["MODERATORS"]) ? $context["MODERATORS"] : null)) {
                // line 68
                echo "\t\t\t<p class=\"moderators\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MODERATORS");
                echo ": ";
                echo (isset($context["MODERATORS"]) ? $context["MODERATORS"] : null);
                echo "</p>
\t\t";
            }
            // line 70
            echo "\t\t";
            if ((isset($context["U_MCP"]) ? $context["U_MCP"] : null)) {
                // line 71
                echo "\t\t\t<p class=\"linkmcp\">[ <a href=\"";
                echo (isset($context["U_MCP"]) ? $context["U_MCP"] : null);
                echo "\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MCP");
                echo "</a> ]</p>
\t\t";
            }
            // line 73
            echo "\t</div>

\t<br clear=\"all\" /><br />
";
        }
        // line 77
        echo "
";
        // line 78
        if ( !(isset($context["S_SHOW_PM_BOX"]) ? $context["S_SHOW_PM_BOX"] : null)) {
            // line 79
            echo "\t<form action=\"";
            echo (isset($context["S_POST_ACTION"]) ? $context["S_POST_ACTION"] : null);
            echo "\" method=\"post\" name=\"postform\"";
            echo (isset($context["S_FORM_ENCTYPE"]) ? $context["S_FORM_ENCTYPE"] : null);
            echo ">
";
        }
        // line 81
        echo "
";
        // line 82
        if ((isset($context["S_DRAFT_LOADED"]) ? $context["S_DRAFT_LOADED"] : null)) {
            // line 83
            echo "\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t<tr>
\t\t\t<th align=\"center\">";
            // line 85
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("INFORMATION");
            echo "</th>
\t\t</tr>
\t\t<tr>
\t\t\t<td class=\"row1\" align=\"center\"><span class=\"gen\">";
            // line 88
            if ((isset($context["S_PRIVMSGS"]) ? $context["S_PRIVMSGS"] : null)) {
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DRAFT_LOADED_PM");
            } else {
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DRAFT_LOADED");
            }
            echo "</span></td>
\t\t</tr>
\t</table>
<br clear=\"all\" />
";
        }
        // line 93
        echo "
";
        // line 94
        if ((isset($context["S_SHOW_DRAFTS"]) ? $context["S_SHOW_DRAFTS"] : null)) {
            // line 95
            echo "\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t<tr>
\t\t\t<th colspan=\"3\" align=\"center\">";
            // line 97
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOAD_DRAFT");
            echo "</th>
\t\t</tr>
\t\t<tr>
\t\t\t<td class=\"row1\" colspan=\"3\" align=\"center\"><span class=\"gen\">";
            // line 100
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOAD_DRAFT_EXPLAIN");
            echo "</span></td>
\t\t</tr>
\t\t<tr>
\t\t\t<th>";
            // line 103
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SAVE_DATE");
            echo "</th>
\t\t\t<th>";
            // line 104
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DRAFT_TITLE");
            echo "</th>
\t\t\t<th>";
            // line 105
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("OPTIONS");
            echo "</th>
\t\t</tr>
\t";
            // line 107
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "draftrow", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["draftrow"]) {
                // line 108
                echo "\t";
                if (($this->getAttribute($context["draftrow"], "S_ROW_COUNT", array()) % 2 == 0)) {
                    // line 109
                    echo "\t\t<tr class=\"row1\">";
                } else {
                    echo "<tr class=\"row2\">";
                }
                // line 110
                echo "\t\t\t<td class=\"postdetails\" style=\"padding: 4px;\">";
                echo $this->getAttribute($context["draftrow"], "DATE", array());
                echo "</td>
\t\t\t<td style=\"padding: 4px;\"><b class=\"gen\">";
                // line 111
                echo $this->getAttribute($context["draftrow"], "DRAFT_SUBJECT", array());
                echo "</b>
\t\t\t\t";
                // line 112
                if ($this->getAttribute($context["draftrow"], "S_LINK_TOPIC", array())) {
                    echo "<br /><span class=\"gensmall\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC");
                    echo ": <a href=\"";
                    echo $this->getAttribute($context["draftrow"], "U_VIEW", array());
                    echo "\">";
                    echo $this->getAttribute($context["draftrow"], "TITLE", array());
                    echo "</a></span>
\t\t\t\t";
                } elseif ($this->getAttribute(                // line 113
$context["draftrow"], "S_LINK_FORUM", array())) {
                    echo "<br /><span class=\"gensmall\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM");
                    echo ": <a href=\"";
                    echo $this->getAttribute($context["draftrow"], "U_VIEW", array());
                    echo "\">";
                    echo $this->getAttribute($context["draftrow"], "TITLE", array());
                    echo "</a></span>
\t\t\t\t";
                } elseif ($this->getAttribute(                // line 114
$context["draftrow"], "S_LINK_PM", array())) {
                    echo "<br /><span class=\"gensmall\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("PRIVATE_MESSAGE");
                    echo "</span>
\t\t\t\t";
                } else {
                    // line 115
                    echo "<br /><span class=\"gensmall\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPIC_FORUM");
                    echo "</span>";
                }
                // line 116
                echo "\t\t\t</td>
\t\t\t<td style=\"padding: 4px;\" align=\"center\"><span class=\"gen\"><a href=\"";
                // line 117
                echo $this->getAttribute($context["draftrow"], "U_INSERT", array());
                echo "\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOAD_DRAFT");
                echo "</a></span></td>
\t\t</tr>
\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['draftrow'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 120
            echo "\t</table>

\t<br clear=\"all\" />
";
        }
        // line 124
        echo "

";
        // line 126
        if ((isset($context["S_POST_REVIEW"]) ? $context["S_POST_REVIEW"] : null)) {
            $location = "posting_review.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("posting_review.html", "posting_body.html", 126)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        }
        // line 127
        if ((isset($context["S_DISPLAY_PREVIEW"]) ? $context["S_DISPLAY_PREVIEW"] : null)) {
            $location = "posting_preview.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("posting_preview.html", "posting_body.html", 127)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        }
        // line 128
        echo "

";
        // line 130
        if (( !(isset($context["S_PRIVMSGS"]) ? $context["S_PRIVMSGS"] : null) && (isset($context["S_UNGLOBALISE"]) ? $context["S_UNGLOBALISE"] : null))) {
            // line 131
            echo "\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t<tr>
\t\t\t<th>";
            // line 133
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MOVE");
            echo "</th>
\t\t</tr>
\t\t<tr>
\t\t\t<td class=\"spacer\" colspan=\"2\"><img src=\"images/spacer.gif\" alt=\"\" width=\"1\" height=\"1\" /></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td class=\"row2\" align=\"center\"><span class=\"gen\">";
            // line 139
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("UNGLOBALISE_EXPLAIN");
            echo "<br /><br />";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SELECT_DESTINATION_FORUM");
            echo "&nbsp;&nbsp;</span><select name=\"to_forum_id\">";
            echo (isset($context["S_FORUM_SELECT"]) ? $context["S_FORUM_SELECT"] : null);
            echo "</select><br /><br /><input class=\"btnmain\" type=\"submit\" name=\"post\" value=\"";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CONFIRM");
            echo "\" />&nbsp;&nbsp; <input class=\"btnlite\" type=\"submit\" name=\"cancel_unglobalise\" value=\"";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CANCEL");
            echo "\" /></td>
\t\t</tr>
\t</table>

\t<br clear=\"all\" />
";
        }
        // line 145
        echo "
\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t<tr>
\t\t\t<th colspan=\"2\"><b>";
        // line 148
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POST_A");
        echo "</b></th>
\t\t</tr>

";
        // line 151
        if ((isset($context["ERROR"]) ? $context["ERROR"] : null)) {
            // line 152
            echo "\t\t<tr>
\t\t\t<td class=\"row2\" colspan=\"2\" align=\"center\"><span class=\"genmed error\">";
            // line 153
            echo (isset($context["ERROR"]) ? $context["ERROR"] : null);
            echo "</span></td>
\t\t</tr>
";
        }
        // line 156
        echo "
";
        // line 157
        if ((isset($context["S_DELETE_ALLOWED"]) ? $context["S_DELETE_ALLOWED"] : null)) {
            // line 158
            echo "\t\t<tr>
\t\t\t<td class=\"row1\"><b class=\"genmed\">";
            // line 159
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DELETE_POST");
            echo ":</b></td>
\t\t\t<td class=\"row2\"><input type=\"checkbox\" class=\"radio\" name=\"delete\" /> <span class=\"gensmall\">[ ";
            // line 160
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DELETE_POST_WARN");
            echo " ]</span></td>
\t\t</tr>
";
        }
        // line 163
        echo "
";
        // line 164
        if (((isset($context["S_SHOW_TOPIC_ICONS"]) ? $context["S_SHOW_TOPIC_ICONS"] : null) || (isset($context["S_SHOW_PM_ICONS"]) ? $context["S_SHOW_PM_ICONS"] : null))) {
            // line 165
            echo "\t\t<tr>
\t\t\t<td class=\"row1\"><b class=\"genmed\">";
            // line 166
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ICON");
            echo ":</b></td>
\t\t\t<td class=\"row2\">
\t\t\t\t<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><input type=\"radio\" class=\"radio\" name=\"icon\" value=\"0\"";
            // line 170
            echo (isset($context["S_NO_ICON_CHECKED"]) ? $context["S_NO_ICON_CHECKED"] : null);
            echo " /><span class=\"genmed\">";
            if ((isset($context["S_SHOW_TOPIC_ICONS"]) ? $context["S_SHOW_TOPIC_ICONS"] : null)) {
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPIC_ICON");
            } else {
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_PM_ICON");
            }
            echo "</span> ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "topic_icon", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["topic_icon"]) {
                echo "<span style=\"white-space: nowrap;\"><input type=\"radio\" class=\"radio\" name=\"icon\" value=\"";
                echo $this->getAttribute($context["topic_icon"], "ICON_ID", array());
                echo "\"";
                echo $this->getAttribute($context["topic_icon"], "S_ICON_CHECKED", array());
                echo " /><img src=\"";
                echo $this->getAttribute($context["topic_icon"], "ICON_IMG", array());
                echo "\" width=\"";
                echo $this->getAttribute($context["topic_icon"], "ICON_WIDTH", array());
                echo "\" height=\"";
                echo $this->getAttribute($context["topic_icon"], "ICON_HEIGHT", array());
                echo "\" alt=\"\" title=\"\" hspace=\"2\" vspace=\"2\" /></span> ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['topic_icon'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
";
        }
        // line 176
        echo "
";
        // line 177
        if (( !(isset($context["S_PRIVMSGS"]) ? $context["S_PRIVMSGS"] : null) && (isset($context["S_DISPLAY_USERNAME"]) ? $context["S_DISPLAY_USERNAME"] : null))) {
            // line 178
            echo "\t\t<tr>
\t\t\t<td class=\"row1\"><b class=\"genmed\">";
            // line 179
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("USERNAME");
            echo ":</b></td>
\t\t\t<td class=\"row2\"><input class=\"post\" type=\"text\" tabindex=\"1\" name=\"username\" size=\"25\" value=\"";
            // line 180
            echo (isset($context["USERNAME"]) ? $context["USERNAME"] : null);
            echo "\" /></td>
\t\t</tr>
";
        }
        // line 183
        echo "
";
        // line 184
        if ((isset($context["S_PRIVMSGS"]) ? $context["S_PRIVMSGS"] : null)) {
            // line 185
            echo "\t\t<tr>
\t\t\t<td class=\"row1\"><b class=\"genmed\">";
            // line 186
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TO");
            echo ":</b></td>
\t\t\t<td class=\"row2\">
\t\t\t\t";
            // line 188
            echo (isset($context["S_HIDDEN_ADDRESS_FIELD"]) ? $context["S_HIDDEN_ADDRESS_FIELD"] : null);
            echo "
\t\t\t";
            // line 189
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "to_recipient", array()));
            $context['_iterated'] = false;
            foreach ($context['_seq'] as $context["_key"] => $context["to_recipient"]) {
                // line 190
                echo "\t\t\t\t<span style=\"display: block; float: ";
                echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
                echo ";\" class=\"nowrap genmed\"><strong>
\t\t\t\t";
                // line 191
                if ($this->getAttribute($context["to_recipient"], "IS_GROUP", array())) {
                    echo "<a href=\"";
                    echo $this->getAttribute($context["to_recipient"], "U_VIEW", array());
                    echo "\"><span class=\"sep\">";
                    echo $this->getAttribute($context["to_recipient"], "NAME", array());
                    echo "</span></a>";
                } else {
                    echo $this->getAttribute($context["to_recipient"], "NAME_FULL", array());
                }
                echo "</strong>&nbsp;";
                if ( !(isset($context["S_EDIT_POST"]) ? $context["S_EDIT_POST"] : null)) {
                    echo "<input class=\"post\" type=\"submit\" name=\"remove_";
                    echo $this->getAttribute($context["to_recipient"], "TYPE", array());
                    echo "[";
                    echo $this->getAttribute($context["to_recipient"], "UG_ID", array());
                    echo "]\" value=\"";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("REMOVE");
                    echo "\" />&nbsp;";
                }
                // line 192
                echo "\t\t\t\t</span>
\t\t\t";
                $context['_iterated'] = true;
            }
            if (!$context['_iterated']) {
                // line 194
                echo "\t\t\t\t<span class=\"genmed\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TO_RECIPIENT");
                echo "</span>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['to_recipient'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 196
            echo "\t\t\t</td>
\t\t</tr>
\t";
            // line 198
            if ((isset($context["S_ALLOW_MASS_PM"]) ? $context["S_ALLOW_MASS_PM"] : null)) {
                // line 199
                echo "\t\t<tr>
\t\t\t<td class=\"row1\"><b class=\"genmed\">";
                // line 200
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("BCC");
                echo ":</b></td>
\t\t\t<td class=\"row2\">
\t\t\t";
                // line 202
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "bcc_recipient", array()));
                $context['_iterated'] = false;
                foreach ($context['_seq'] as $context["_key"] => $context["bcc_recipient"]) {
                    // line 203
                    echo "\t\t\t\t<span class=\"genmed nowrap\"><strong>
\t\t\t\t";
                    // line 204
                    if ($this->getAttribute($context["bcc_recipient"], "IS_GROUP", array())) {
                        echo "<a href=\"";
                        echo $this->getAttribute($context["bcc_recipient"], "U_VIEW", array());
                        echo "\"><span class=\"sep\">";
                        echo $this->getAttribute($context["bcc_recipient"], "NAME", array());
                        echo "</span></a>";
                    } else {
                        echo $this->getAttribute($context["bcc_recipient"], "NAME_FULL", array());
                    }
                    echo "</strong>&nbsp;";
                    if ( !(isset($context["S_EDIT_POST"]) ? $context["S_EDIT_POST"] : null)) {
                        echo "<input class=\"post\" type=\"submit\" name=\"remove_";
                        echo $this->getAttribute($context["bcc_recipient"], "TYPE", array());
                        echo "[";
                        echo $this->getAttribute($context["bcc_recipient"], "UG_ID", array());
                        echo "]\" value=\"";
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("REMOVE");
                        echo "\" />&nbsp;";
                    }
                    // line 205
                    echo "\t\t\t\t</span>
\t\t\t";
                    $context['_iterated'] = true;
                }
                if (!$context['_iterated']) {
                    // line 207
                    echo "\t\t\t\t<span class=\"genmed\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_BCC_RECIPIENT");
                    echo "</span>
\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['bcc_recipient'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 209
                echo "\t\t\t</td>
\t\t</tr>
\t";
            }
        }
        // line 213
        echo "
\t\t<tr>
\t\t\t<td class=\"row1\" width=\"22%\"><b class=\"genmed\">";
        // line 215
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SUBJECT");
        echo ":</b></td>
\t\t\t<td class=\"row2\" width=\"78%\"><input class=\"post\" style=\"width:450px\" type=\"text\" name=\"subject\" size=\"45\" maxlength=\"";
        // line 216
        if ((isset($context["S_NEW_MESSAGE"]) ? $context["S_NEW_MESSAGE"] : null)) {
            echo "60";
        } else {
            echo "64";
        }
        echo "\" tabindex=\"2\" value=\"";
        echo (isset($context["SUBJECT"]) ? $context["SUBJECT"] : null);
        echo "\" /></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td class=\"row1\" valign=\"top\"><b class=\"genmed\">";
        // line 219
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MESSAGE_BODY");
        echo ":</b><br /><span class=\"gensmall\">";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MESSAGE_BODY_EXPLAIN");
        echo "&nbsp;</span><br /><br />
\t\t\t";
        // line 220
        if ((isset($context["S_SMILIES_ALLOWED"]) ? $context["S_SMILIES_ALLOWED"] : null)) {
            // line 221
            echo "\t\t\t\t<table width=\"100%\" cellspacing=\"5\" cellpadding=\"0\" border=\"0\" align=\"center\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"gensmall\" align=\"center\"><b>";
            // line 223
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SMILIES");
            echo "</b></td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td align=\"center\">
\t\t\t\t\t\t\t";
            // line 227
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "smiley", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["smiley"]) {
                // line 228
                echo "\t\t\t\t\t\t\t\t<a href=\"#\" onclick=\"insert_text('";
                echo $this->getAttribute($context["smiley"], "A_SMILEY_CODE", array());
                echo "', true); return false;\" style=\"line-height: 20px;\"><img src=\"";
                echo $this->getAttribute($context["smiley"], "SMILEY_IMG", array());
                echo "\" width=\"";
                echo $this->getAttribute($context["smiley"], "SMILEY_WIDTH", array());
                echo "\" height=\"";
                echo $this->getAttribute($context["smiley"], "SMILEY_HEIGHT", array());
                echo "\" alt=\"";
                echo $this->getAttribute($context["smiley"], "SMILEY_CODE", array());
                echo "\" title=\"";
                echo $this->getAttribute($context["smiley"], "SMILEY_DESC", array());
                echo "\" hspace=\"2\" vspace=\"2\" /></a>
\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['smiley'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 230
            echo "\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>

\t\t\t\t";
            // line 233
            if ((isset($context["S_SHOW_SMILEY_LINK"]) ? $context["S_SHOW_SMILEY_LINK"] : null)) {
                // line 234
                echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td align=\"center\"><a class=\"nav\" href=\"";
                // line 235
                echo (isset($context["U_MORE_SMILIES"]) ? $context["U_MORE_SMILIES"] : null);
                echo "\" onclick=\"popup(this.href, 300, 350, '_phpbbsmilies'); return false;\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MORE_SMILIES");
                echo "</a></td>
\t\t\t\t\t</tr>
\t\t\t\t";
            }
            // line 238
            echo "
\t\t\t\t</table>
\t\t\t";
        }
        // line 241
        echo "\t\t\t</td>
\t\t\t<td class=\"row2\" valign=\"top\">
\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t// <![CDATA[
\t\t\t\t\tvar form_name = 'postform';
\t\t\t\t\tvar text_name = 'message';
\t\t\t\t// ]]>
\t\t\t\t</script>

\t\t\t\t<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">
\t\t\t\t";
        // line 251
        $location = "posting_buttons.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("posting_buttons.html", "posting_body.html", 251)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 252
        echo "\t\t\t\t<tr>
\t\t\t\t\t<td valign=\"top\" style=\"width: 100%;\"><textarea name=\"message\" rows=\"15\" cols=\"76\" tabindex=\"3\" onselect=\"storeCaret(this);\" onclick=\"storeCaret(this);\" onkeyup=\"storeCaret(this);\" onfocus=\"initInsertions();\" style=\"width: 98%;\">";
        // line 253
        echo (isset($context["MESSAGE"]) ? $context["MESSAGE"] : null);
        echo "</textarea></td>
\t\t\t\t\t";
        // line 254
        if ((isset($context["S_BBCODE_ALLOWED"]) ? $context["S_BBCODE_ALLOWED"] : null)) {
            // line 255
            echo "\t\t\t\t\t<td width=\"80\" align=\"center\" valign=\"top\">
\t\t\t\t\t\t<script type=\"text/javascript\">
\t\t\t\t\t\t// <![CDATA[
\t\t\t\t\t\t\tcolorPalette('v', 7, 6)
\t\t\t\t\t\t// ]]>
\t\t\t\t\t\t</script>
\t\t\t\t\t</td>
\t\t\t\t\t";
        }
        // line 263
        echo "\t\t\t \t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>

";
        // line 268
        if ((isset($context["S_INLINE_ATTACHMENT_OPTIONS"]) ? $context["S_INLINE_ATTACHMENT_OPTIONS"] : null)) {
            // line 269
            echo "\t\t<tr>
\t\t\t<td class=\"row1\"><b class=\"genmed\">";
            // line 270
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ATTACHMENTS");
            echo ":</b></td>
\t\t\t<td class=\"row2\"><select name=\"attachments\">";
            // line 271
            echo (isset($context["S_INLINE_ATTACHMENT_OPTIONS"]) ? $context["S_INLINE_ATTACHMENT_OPTIONS"] : null);
            echo "</select>&nbsp;<input type=\"button\" class=\"btnbbcode\" accesskey=\"a\" value=\"";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("PLACE_INLINE");
            echo "\" name=\"attachinline\" onclick=\"attach_form = document.forms[form_name].elements['attachments']; attach_inline(attach_form.value, attach_form.options[attach_form.selectedIndex].text);\" onmouseover=\"helpline('a')\" onmouseout=\"helpline('tip')\" />
\t\t\t</td>
\t\t</tr>
";
        }
        // line 275
        echo "
\t\t<tr>
\t\t\t<td class=\"row1\" valign=\"top\"><b class=\"genmed\">";
        // line 277
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("OPTIONS");
        echo ":</b><br />
\t\t\t\t<table cellspacing=\"2\" cellpadding=\"0\" border=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"gensmall\">";
        // line 280
        echo (isset($context["BBCODE_STATUS"]) ? $context["BBCODE_STATUS"] : null);
        echo "</td>
\t\t\t\t\t</tr>
\t\t\t\t\t";
        // line 282
        if ((isset($context["S_BBCODE_ALLOWED"]) ? $context["S_BBCODE_ALLOWED"] : null)) {
            // line 283
            echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 284
            echo (isset($context["IMG_STATUS"]) ? $context["IMG_STATUS"] : null);
            echo "</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 287
            echo (isset($context["FLASH_STATUS"]) ? $context["FLASH_STATUS"] : null);
            echo "</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 290
            echo (isset($context["URL_STATUS"]) ? $context["URL_STATUS"] : null);
            echo "</td>
\t\t\t\t\t</tr>
\t\t\t\t\t";
        }
        // line 293
        echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"gensmall\">";
        // line 294
        echo (isset($context["SMILIES_STATUS"]) ? $context["SMILIES_STATUS"] : null);
        echo "</td>
\t\t\t\t\t</tr>
\t\t\t\t
\t\t\t\t</table>
\t\t\t</td>
\t\t\t<td class=\"row2\">
\t\t\t\t<table cellpadding=\"1\">
\t\t\t\t";
        // line 301
        if ((isset($context["S_BBCODE_ALLOWED"]) ? $context["S_BBCODE_ALLOWED"] : null)) {
            // line 302
            echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><input type=\"checkbox\" class=\"radio\" name=\"disable_bbcode\"";
            // line 303
            echo (isset($context["S_BBCODE_CHECKED"]) ? $context["S_BBCODE_CHECKED"] : null);
            echo " /></td>
\t\t\t\t\t\t<td class=\"gen\">";
            // line 304
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DISABLE_BBCODE");
            echo "</td>
\t\t\t\t\t</tr>
\t\t\t\t";
        }
        // line 307
        echo "
\t\t\t\t";
        // line 308
        if ((isset($context["S_SMILIES_ALLOWED"]) ? $context["S_SMILIES_ALLOWED"] : null)) {
            // line 309
            echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><input type=\"checkbox\" class=\"radio\" name=\"disable_smilies\"";
            // line 310
            echo (isset($context["S_SMILIES_CHECKED"]) ? $context["S_SMILIES_CHECKED"] : null);
            echo " /></td>
\t\t\t\t\t\t<td class=\"gen\">";
            // line 311
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DISABLE_SMILIES");
            echo "</td>
\t\t\t\t\t</tr>
\t\t\t\t";
        }
        // line 314
        echo "
\t\t\t\t";
        // line 315
        if ((isset($context["S_LINKS_ALLOWED"]) ? $context["S_LINKS_ALLOWED"] : null)) {
            // line 316
            echo "\t\t\t\t<tr>
\t\t\t\t\t<td><input type=\"checkbox\" class=\"radio\" name=\"disable_magic_url\"";
            // line 317
            echo (isset($context["S_MAGIC_URL_CHECKED"]) ? $context["S_MAGIC_URL_CHECKED"] : null);
            echo " /></td>
\t\t\t\t\t<td class=\"gen\">";
            // line 318
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DISABLE_MAGIC_URL");
            echo "</td>
\t\t\t\t</tr>
\t\t\t\t";
        }
        // line 321
        echo "
\t\t\t\t";
        // line 322
        if ((isset($context["S_SIG_ALLOWED"]) ? $context["S_SIG_ALLOWED"] : null)) {
            // line 323
            echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><input type=\"checkbox\" class=\"radio\" name=\"attach_sig\"";
            // line 324
            echo (isset($context["S_SIGNATURE_CHECKED"]) ? $context["S_SIGNATURE_CHECKED"] : null);
            echo " /></td>
\t\t\t\t\t\t<td class=\"gen\">";
            // line 325
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ATTACH_SIG");
            echo "</td>
\t\t\t\t\t</tr>
\t\t";
        }
        // line 328
        echo "
\t\t";
        // line 329
        if ((isset($context["S_NOTIFY_ALLOWED"]) ? $context["S_NOTIFY_ALLOWED"] : null)) {
            // line 330
            echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><input type=\"checkbox\" class=\"radio\" name=\"notify\"";
            // line 331
            echo (isset($context["S_NOTIFY_CHECKED"]) ? $context["S_NOTIFY_CHECKED"] : null);
            echo " /></td>
\t\t\t\t\t\t<td class=\"gen\">";
            // line 332
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NOTIFY_REPLY");
            echo "</td>
\t\t\t\t\t</tr>
\t\t";
        }
        // line 335
        echo "
\t\t";
        // line 336
        if ( !(isset($context["S_PRIVMSGS"]) ? $context["S_PRIVMSGS"] : null)) {
            // line 337
            echo "\t\t\t";
            if ((isset($context["S_LOCK_TOPIC_ALLOWED"]) ? $context["S_LOCK_TOPIC_ALLOWED"] : null)) {
                // line 338
                echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><input type=\"checkbox\" class=\"radio\" name=\"lock_topic\"";
                // line 339
                echo (isset($context["S_LOCK_TOPIC_CHECKED"]) ? $context["S_LOCK_TOPIC_CHECKED"] : null);
                echo " /></td>
\t\t\t\t\t\t<td class=\"gen\">";
                // line 340
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOCK_TOPIC");
                echo "</td>
\t\t\t\t\t</tr>
\t\t\t";
            }
            // line 343
            echo "
\t\t\t";
            // line 344
            if ((isset($context["S_LOCK_POST_ALLOWED"]) ? $context["S_LOCK_POST_ALLOWED"] : null)) {
                // line 345
                echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><input type=\"checkbox\" class=\"radio\" name=\"lock_post\"";
                // line 346
                echo (isset($context["S_LOCK_POST_CHECKED"]) ? $context["S_LOCK_POST_CHECKED"] : null);
                echo " /></td>
\t\t\t\t\t\t<td class=\"gen\">";
                // line 347
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOCK_POST");
                echo " [";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOCK_POST_EXPLAIN");
                echo "]</td>
\t\t\t\t\t</tr>
\t\t\t";
            }
            // line 350
            echo "
\t\t\t";
            // line 351
            if ((isset($context["S_TYPE_TOGGLE"]) ? $context["S_TYPE_TOGGLE"] : null)) {
                // line 352
                echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td>&nbsp;</td>
\t\t\t\t\t\t<td class=\"gen\">";
                // line 354
                if ((isset($context["S_EDIT_POST"]) ? $context["S_EDIT_POST"] : null)) {
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CHANGE_TOPIC_TO");
                } else {
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POST_TOPIC_AS");
                }
                echo ": ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "topic_type", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["topic_type"]) {
                    echo "<input type=\"radio\" class=\"radio\" name=\"topic_type\" value=\"";
                    echo $this->getAttribute($context["topic_type"], "VALUE", array());
                    echo "\"";
                    echo $this->getAttribute($context["topic_type"], "S_CHECKED", array());
                    echo " />";
                    echo $this->getAttribute($context["topic_type"], "L_TOPIC_TYPE", array());
                    echo "&nbsp;&nbsp;";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['topic_type'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                echo "</td>
\t\t\t\t\t</tr>
\t\t\t";
            }
            // line 357
            echo "\t\t";
        }
        // line 358
        echo "\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>

";
        // line 362
        if (((isset($context["S_TOPIC_TYPE_ANNOUNCE"]) ? $context["S_TOPIC_TYPE_ANNOUNCE"] : null) || (isset($context["S_TOPIC_TYPE_STICKY"]) ? $context["S_TOPIC_TYPE_STICKY"] : null))) {
            // line 363
            echo "\t\t<tr>
\t\t\t<td class=\"row1\"><b class=\"genmed\">";
            // line 364
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("STICK_TOPIC_FOR");
            echo ":</b><br /><span class=\"gensmall\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("STICKY_ANNOUNCE_TIME_LIMIT");
            echo "</span></td>
\t\t\t<td class=\"row2\"><input class=\"post\" type=\"text\" name=\"topic_time_limit\" size=\"3\" maxlength=\"3\" value=\"";
            // line 365
            echo (isset($context["TOPIC_TIME_LIMIT"]) ? $context["TOPIC_TIME_LIMIT"] : null);
            echo "\" />&nbsp;<b class=\"gen\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DAYS");
            echo "</b> <span class=\"gensmall\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("STICK_TOPIC_FOR_EXPLAIN");
            echo "</span></td>
\t\t</tr>
";
        }
        // line 368
        echo "
";
        // line 369
        if ((isset($context["S_EDIT_REASON"]) ? $context["S_EDIT_REASON"] : null)) {
            // line 370
            echo "\t\t<tr>
\t\t\t<td class=\"row1\" valign=\"top\"><b class=\"genmed\">";
            // line 371
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("EDIT_REASON");
            echo ":</b></td>
\t\t\t<td class=\"row2\"><input class=\"post\" type=\"text\" name=\"edit_reason\" size=\"50\" value=\"";
            // line 372
            echo (isset($context["EDIT_REASON"]) ? $context["EDIT_REASON"] : null);
            echo "\" /></td>
\t\t</tr>
";
        }
        // line 375
        echo "
";
        // line 376
        if (((isset($context["CAPTCHA_TEMPLATE"]) ? $context["CAPTCHA_TEMPLATE"] : null) && (isset($context["S_CONFIRM_CODE"]) ? $context["S_CONFIRM_CODE"] : null))) {
            // line 377
            echo "\t\t";
            $location = (("" . (isset($context["CAPTCHA_TEMPLATE"]) ? $context["CAPTCHA_TEMPLATE"] : null)) . "");
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate((("" . (isset($context["CAPTCHA_TEMPLATE"]) ? $context["CAPTCHA_TEMPLATE"] : null)) . ""), "posting_body.html", 377)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
            // line 378
            echo "\t\t";
        }
        // line 379
        echo "
";
        // line 380
        if (((isset($context["S_SHOW_ATTACH_BOX"]) ? $context["S_SHOW_ATTACH_BOX"] : null) || (isset($context["S_SHOW_POLL_BOX"]) ? $context["S_SHOW_POLL_BOX"] : null))) {
            // line 381
            echo "\t\t<tr>
\t\t\t<td class=\"cat\" colspan=\"2\" align=\"center\">
\t\t\t\t<input class=\"btnlite\" type=\"submit\" tabindex=\"5\" name=\"preview\" value=\"";
            // line 383
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("PREVIEW");
            echo "\" />
\t\t\t\t&nbsp; <input class=\"btnmain\" type=\"submit\" accesskey=\"s\" tabindex=\"6\" name=\"post\" value=\"";
            // line 384
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SUBMIT");
            echo "\" />
\t\t\t\t";
            // line 385
            if ((isset($context["S_SAVE_ALLOWED"]) ? $context["S_SAVE_ALLOWED"] : null)) {
                echo "&nbsp; <input class=\"btnlite\" type=\"submit\" accesskey=\"k\" tabindex=\"7\" name=\"save\" value=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SAVE_DRAFT");
                echo "\" />";
            }
            // line 386
            echo "\t\t\t\t";
            if ((isset($context["S_HAS_DRAFTS"]) ? $context["S_HAS_DRAFTS"] : null)) {
                echo "&nbsp; <input class=\"btnlite\" type=\"submit\" accesskey=\"d\" tabindex=\"8\" name=\"load\" value=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOAD_DRAFT");
                echo "\" />";
            }
            // line 387
            echo "\t\t\t\t&nbsp; <input class=\"btnlite\" type=\"submit\" accesskey=\"c\" tabindex=\"9\" name=\"cancel\" value=\"";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CANCEL");
            echo "\" />
\t\t\t</td>
\t\t</tr>

\t";
            // line 391
            if ((isset($context["S_SHOW_ATTACH_BOX"]) ? $context["S_SHOW_ATTACH_BOX"] : null)) {
                $location = "posting_attach_body.html";
                $namespace = false;
                if (strpos($location, '@') === 0) {
                    $namespace = substr($location, 1, strpos($location, '/') - 1);
                    $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                    $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
                }
                $this->loadTemplate("posting_attach_body.html", "posting_body.html", 391)->display($context);
                if ($namespace) {
                    $this->env->setNamespaceLookUpOrder($previous_look_up_order);
                }
            }
            // line 392
            echo "
\t";
            // line 393
            if ((isset($context["S_SHOW_POLL_BOX"]) ? $context["S_SHOW_POLL_BOX"] : null)) {
                // line 394
                echo "\t\t";
                $location = "posting_poll_body.html";
                $namespace = false;
                if (strpos($location, '@') === 0) {
                    $namespace = substr($location, 1, strpos($location, '/') - 1);
                    $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                    $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
                }
                $this->loadTemplate("posting_poll_body.html", "posting_body.html", 394)->display($context);
                if ($namespace) {
                    $this->env->setNamespaceLookUpOrder($previous_look_up_order);
                }
                // line 395
                echo "\t";
            } elseif ((isset($context["S_POLL_DELETE"]) ? $context["S_POLL_DELETE"] : null)) {
                // line 396
                echo "\t\t<tr>
\t\t\t<td class=\"row1\"><span class=\"genmed\"><b>";
                // line 397
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POLL_DELETE");
                echo ":</b></span></td>
\t\t\t<td class=\"row2\"><input type=\"checkbox\" class=\"radio\" name=\"poll_delete\" /></td>
\t\t</tr>
\t";
            }
        }
        // line 402
        echo "
\t\t<tr>
\t\t\t<td class=\"cat\" colspan=\"2\" align=\"center\">";
        // line 404
        echo (isset($context["S_HIDDEN_FIELDS"]) ? $context["S_HIDDEN_FIELDS"] : null);
        echo "
\t\t\t\t<input class=\"btnlite\" type=\"submit\" tabindex=\"10\" name=\"preview\" value=\"";
        // line 405
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("PREVIEW");
        echo "\" />
\t\t\t\t&nbsp; <input class=\"btnmain\" type=\"submit\" accesskey=\"s\" tabindex=\"11\" name=\"post\" value=\"";
        // line 406
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SUBMIT");
        echo "\" />
\t\t\t\t";
        // line 407
        if (( !(isset($context["S_SHOW_ATTACH_BOX"]) ? $context["S_SHOW_ATTACH_BOX"] : null) &&  !(isset($context["S_SHOW_POLL_BOX"]) ? $context["S_SHOW_POLL_BOX"] : null))) {
            // line 408
            echo "\t\t\t\t\t";
            if ((isset($context["S_SAVE_ALLOWED"]) ? $context["S_SAVE_ALLOWED"] : null)) {
                echo "&nbsp; <input class=\"btnlite\" type=\"submit\" accesskey=\"k\" tabindex=\"12\" name=\"save\" value=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SAVE_DRAFT");
                echo "\" />";
            }
            // line 409
            echo "\t\t\t\t\t";
            if ((isset($context["S_HAS_DRAFTS"]) ? $context["S_HAS_DRAFTS"] : null)) {
                echo "&nbsp; <input class=\"btnlite\" type=\"submit\" accesskey=\"d\" tabindex=\"13\" name=\"load\" value=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOAD_DRAFT");
                echo "\" />";
            }
            // line 410
            echo "\t\t\t\t";
        }
        // line 411
        echo "\t\t\t\t&nbsp; <input class=\"btnlite\" type=\"submit\" accesskey=\"c\" tabindex=\"14\" name=\"cancel\" value=\"";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CANCEL");
        echo "\" />
\t\t\t</td>
\t\t</tr>
\t</table>
    ";
        // line 415
        if ( !(isset($context["S_PRIVMSGS"]) ? $context["S_PRIVMSGS"] : null)) {
            // line 416
            echo "       ";
            echo (isset($context["S_FORM_TOKEN"]) ? $context["S_FORM_TOKEN"] : null);
            echo "
      </form>
    ";
        }
        // line 419
        echo "<br clear=\"all\" />

";
        // line 421
        if ((isset($context["S_DISPLAY_REVIEW"]) ? $context["S_DISPLAY_REVIEW"] : null)) {
            $location = "posting_topic_review.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("posting_topic_review.html", "posting_body.html", 421)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        }
        // line 422
        if ((isset($context["S_DISPLAY_HISTORY"]) ? $context["S_DISPLAY_HISTORY"] : null)) {
            $location = "ucp_pm_history.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("ucp_pm_history.html", "posting_body.html", 422)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        }
        // line 423
        echo "
";
        // line 424
        if ((isset($context["S_PRIVMSGS"]) ? $context["S_PRIVMSGS"] : null)) {
            // line 425
            echo "\t";
            $location = "ucp_footer.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("ucp_footer.html", "posting_body.html", 425)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        } else {
            // line 427
            echo "
";
            // line 428
            $location = "breadcrumbs.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("breadcrumbs.html", "posting_body.html", 428)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
            // line 429
            echo "
\t";
            // line 430
            if ((isset($context["S_DISPLAY_ONLINE_LIST"]) ? $context["S_DISPLAY_ONLINE_LIST"] : null)) {
                // line 431
                echo "\t<br clear=\"all\" />

\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><img src=\"";
                // line 438
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t\t<td style=\"background:url(";
                // line 439
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_02.png);\" width=\"50%\" height=\"48\"></td>
\t\t\t\t   \t\t<td style=\"background:url(";
                // line 440
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/cu.png);\" width=\"350\" height=\"48\"><h4 align=\"center\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("WHO_IS_ONLINE");
                echo "</h4></td>
\t\t\t\t\t\t<td style=\"background:url(";
                // line 441
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_02.png);\" width=\"50%\" height=\"48\"></td>
\t\t\t\t\t\t<td><img src=\"";
                // line 442
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td style=\"background:url(";
                // line 451
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_08.png);\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t\t<td>   
\t\t\t\t\t\t\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td class=\"row1\"><p class=\"gensmall\">";
                // line 455
                echo (isset($context["LOGGED_IN_USER_LIST"]) ? $context["LOGGED_IN_USER_LIST"] : null);
                echo "</p></td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td style=\"background:url(";
                // line 459
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_09.png);\" width=\"9\" height=\"100%\"></td>
\t\t\t\t\t</tr>
\t\t\t\t
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><img src=\"";
                // line 463
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t\t<td style=\"background:url(";
                // line 464
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_11.png);\" width=\"100%\" height=\"46\"></td>
\t\t\t\t\t\t<td><img src=\"";
                // line 465
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t</table>
";
            }
            // line 472
            echo "\t<br clear=\"all\" />
\t<table width=\"100%\" cellspacing=\"1\">
\t\t<tr>
\t\t\t<td align=\"";
            // line 475
            echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
            echo "\">";
            $location = "jumpbox.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("jumpbox.html", "posting_body.html", 475)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
            echo "</td>
\t\t</tr>
\t</table>

";
            // line 479
            $location = "overall_footer.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("overall_footer.html", "posting_body.html", 479)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        }
    }

    public function getTemplateName()
    {
        return "posting_body.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1430 => 479,  1411 => 475,  1406 => 472,  1396 => 465,  1392 => 464,  1388 => 463,  1381 => 459,  1374 => 455,  1367 => 451,  1355 => 442,  1351 => 441,  1345 => 440,  1341 => 439,  1337 => 438,  1328 => 431,  1326 => 430,  1323 => 429,  1311 => 428,  1308 => 427,  1294 => 425,  1292 => 424,  1289 => 423,  1275 => 422,  1261 => 421,  1257 => 419,  1250 => 416,  1248 => 415,  1240 => 411,  1237 => 410,  1230 => 409,  1223 => 408,  1221 => 407,  1217 => 406,  1213 => 405,  1209 => 404,  1205 => 402,  1197 => 397,  1194 => 396,  1191 => 395,  1178 => 394,  1176 => 393,  1173 => 392,  1159 => 391,  1151 => 387,  1144 => 386,  1138 => 385,  1134 => 384,  1130 => 383,  1126 => 381,  1124 => 380,  1121 => 379,  1118 => 378,  1105 => 377,  1103 => 376,  1100 => 375,  1094 => 372,  1090 => 371,  1087 => 370,  1085 => 369,  1082 => 368,  1072 => 365,  1066 => 364,  1063 => 363,  1061 => 362,  1055 => 358,  1052 => 357,  1027 => 354,  1023 => 352,  1021 => 351,  1018 => 350,  1010 => 347,  1006 => 346,  1003 => 345,  1001 => 344,  998 => 343,  992 => 340,  988 => 339,  985 => 338,  982 => 337,  980 => 336,  977 => 335,  971 => 332,  967 => 331,  964 => 330,  962 => 329,  959 => 328,  953 => 325,  949 => 324,  946 => 323,  944 => 322,  941 => 321,  935 => 318,  931 => 317,  928 => 316,  926 => 315,  923 => 314,  917 => 311,  913 => 310,  910 => 309,  908 => 308,  905 => 307,  899 => 304,  895 => 303,  892 => 302,  890 => 301,  880 => 294,  877 => 293,  871 => 290,  865 => 287,  859 => 284,  856 => 283,  854 => 282,  849 => 280,  843 => 277,  839 => 275,  830 => 271,  826 => 270,  823 => 269,  821 => 268,  814 => 263,  804 => 255,  802 => 254,  798 => 253,  795 => 252,  783 => 251,  771 => 241,  766 => 238,  758 => 235,  755 => 234,  753 => 233,  748 => 230,  729 => 228,  725 => 227,  718 => 223,  714 => 221,  712 => 220,  706 => 219,  694 => 216,  690 => 215,  686 => 213,  680 => 209,  671 => 207,  665 => 205,  645 => 204,  642 => 203,  637 => 202,  632 => 200,  629 => 199,  627 => 198,  623 => 196,  614 => 194,  608 => 192,  588 => 191,  583 => 190,  578 => 189,  574 => 188,  569 => 186,  566 => 185,  564 => 184,  561 => 183,  555 => 180,  551 => 179,  548 => 178,  546 => 177,  543 => 176,  509 => 170,  502 => 166,  499 => 165,  497 => 164,  494 => 163,  488 => 160,  484 => 159,  481 => 158,  479 => 157,  476 => 156,  470 => 153,  467 => 152,  465 => 151,  459 => 148,  454 => 145,  437 => 139,  428 => 133,  424 => 131,  422 => 130,  418 => 128,  404 => 127,  390 => 126,  386 => 124,  380 => 120,  369 => 117,  366 => 116,  361 => 115,  354 => 114,  344 => 113,  334 => 112,  330 => 111,  325 => 110,  320 => 109,  317 => 108,  313 => 107,  308 => 105,  304 => 104,  300 => 103,  294 => 100,  288 => 97,  284 => 95,  282 => 94,  279 => 93,  267 => 88,  261 => 85,  257 => 83,  255 => 82,  252 => 81,  244 => 79,  242 => 78,  239 => 77,  233 => 73,  225 => 71,  222 => 70,  214 => 68,  212 => 67,  196 => 66,  193 => 65,  191 => 64,  188 => 63,  184 => 61,  177 => 57,  173 => 56,  169 => 55,  163 => 52,  157 => 49,  151 => 46,  143 => 41,  139 => 40,  133 => 39,  129 => 38,  125 => 37,  121 => 35,  114 => 31,  110 => 30,  106 => 29,  100 => 26,  92 => 23,  86 => 20,  78 => 15,  74 => 14,  68 => 13,  64 => 12,  60 => 11,  56 => 9,  54 => 8,  52 => 7,  49 => 6,  35 => 4,  21 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "posting_body.html", "");
    }
}
