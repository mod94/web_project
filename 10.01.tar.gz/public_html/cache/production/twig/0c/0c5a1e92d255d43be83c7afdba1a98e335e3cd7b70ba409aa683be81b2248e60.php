<?php

/* searchbox.html */
class __TwigTemplate_69a8a0ab19dea8fe98fb7c0646b7852d2f9e66503f1bc74759841eb7e2554d09 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<form method=\"post\" name=\"search\" action=\"";
        echo (isset($context["S_SEARCHBOX_ACTION"]) ? $context["S_SEARCHBOX_ACTION"] : null);
        echo "\"><span class=\"gensmall\">";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SEARCH_FOR");
        echo ":</span> <input class=\"post\" type=\"text\" name=\"keywords\" size=\"20\" /> <input class=\"btnlite\" type=\"submit\" value=\"";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("GO");
        echo "\" /></form>
";
    }

    public function getTemplateName()
    {
        return "searchbox.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "searchbox.html", "");
    }
}
