<?php

/* posting_attach_body.html */
class __TwigTemplate_93b38158f523fff4ee32c48f3b0860a3af69e9e4e06b4ab1f529430dbee9a93a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<tr>
\t<th colspan=\"2\">
\t\t<script type=\"text/javascript\">
\t\t// <![CDATA[
\t\t\t/**
\t\t\t* Show upload progress bar
\t\t\t*/
\t\t\tfunction popup_progress_bar()
\t\t\t{
\t\t\t\tclose_waitscreen = 0;
\t\t\t\t// no scrollbars
\t\t\t\tpopup('";
        // line 12
        echo (isset($context["UA_PROGRESS_BAR"]) ? $context["UA_PROGRESS_BAR"] : null);
        echo "', 400, 200, '_upload');
\t\t\t}
\t\t// ]]>
\t\t</script>

\t\t";
        // line 17
        if ((isset($context["S_CLOSE_PROGRESS_WINDOW"]) ? $context["S_CLOSE_PROGRESS_WINDOW"] : null)) {
            // line 18
            echo "\t\t\t<script type=\"text/javascript\">
\t\t\t// <![CDATA[
\t\t\t\tclose_waitscreen = 1;
\t\t\t// ]]>
\t\t\t</script>
\t\t";
        }
        // line 24
        echo "
\t\t";
        // line 25
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ADD_ATTACHMENT");
        echo "
\t</th>
</tr>
<tr>
\t<td class=\"row3\" colspan=\"2\"><span class=\"gensmall\">";
        // line 29
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ADD_ATTACHMENT_EXPLAIN");
        echo "</span></td>
</tr>

<tr> 
\t<td class=\"row1\"><b class=\"genmed\">";
        // line 33
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FILENAME");
        echo "</b></td> 
\t<td class=\"row2\"><input type=\"file\" name=\"fileupload\" size=\"40\" maxlength=\"";
        // line 34
        echo (isset($context["FILESIZE"]) ? $context["FILESIZE"] : null);
        echo "\" value=\"\" class=\"btnfile\" /></td> 
</tr> 
<tr> 
\t<td class=\"row1\"><b class=\"genmed\">";
        // line 37
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FILE_COMMENT");
        echo "</b></td> 
\t<td class=\"row2\">
\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"2\">
\t\t<tr>
\t\t\t<td><textarea class=\"post\" name=\"filecomment\" rows=\"3\" cols=\"35\">";
        // line 41
        echo (isset($context["FILE_COMMENT"]) ? $context["FILE_COMMENT"] : null);
        echo "</textarea>&nbsp;</td>
\t\t\t<td valign=\"top\">
\t\t\t\t<table border=\"0\" cellspacing=\"4\" cellpadding=\"0\">
\t\t\t\t<tr>
\t\t\t\t\t<td><input class=\"btnlite\" type=\"submit\" style=\"width:150px\" name=\"add_file\" value=\"";
        // line 45
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ADD_FILE");
        echo "\" onclick=\"popup_progress_bar();\" /></td>
\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t\t</table>
\t</td>
</tr> 

";
        // line 54
        if ((isset($context["S_HAS_ATTACHMENTS"]) ? $context["S_HAS_ATTACHMENTS"] : null)) {
            // line 55
            echo "\t<tr>
\t\t<th colspan=\"2\">";
            // line 56
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POSTED_ATTACHMENTS");
            echo "</th>
\t</tr>

\t";
            // line 59
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "attach_row", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["attach_row"]) {
                // line 60
                echo "\t\t<tr>
\t\t\t<td class=\"row1\"><b class=\"genmed\">";
                // line 61
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FILENAME");
                echo "</b></td>
\t\t\t<td class=\"row2\"><a class=\"genmed\" href=\"";
                // line 62
                echo $this->getAttribute($context["attach_row"], "U_VIEW_ATTACHMENT", array());
                echo "\" target=\"_blank\">";
                echo $this->getAttribute($context["attach_row"], "FILENAME", array());
                echo "</a></td> 
\t\t</tr>
\t\t<tr> 
\t\t\t<td class=\"row1\"><b class=\"genmed\">";
                // line 65
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FILE_COMMENT");
                echo "</b></td> 
\t\t\t<td class=\"row2\">";
                // line 66
                echo $this->getAttribute($context["attach_row"], "S_HIDDEN", array());
                echo "
\t\t\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"2\">
\t\t\t\t<tr>
\t\t\t\t\t<td><textarea class=\"post\" name=\"comment_list[";
                // line 69
                echo $this->getAttribute($context["attach_row"], "ASSOC_INDEX", array());
                echo "]\" rows=\"3\" cols=\"35\">";
                echo $this->getAttribute($context["attach_row"], "FILE_COMMENT", array());
                echo "</textarea>&nbsp;</td>
\t\t\t\t\t<td valign=\"top\">
\t\t\t\t\t\t<table border=\"0\" cellspacing=\"4\" cellpadding=\"0\">
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td><input class=\"btnlite\" type=\"submit\" style=\"width:150px\" name=\"delete_file[";
                // line 73
                echo $this->getAttribute($context["attach_row"], "ASSOC_INDEX", array());
                echo "]\" value=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DELETE_FILE");
                echo "\" /></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</table>
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['attach_row'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 82
            echo "
";
        }
    }

    public function getTemplateName()
    {
        return "posting_attach_body.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 82,  152 => 73,  143 => 69,  137 => 66,  133 => 65,  125 => 62,  121 => 61,  118 => 60,  114 => 59,  108 => 56,  105 => 55,  103 => 54,  91 => 45,  84 => 41,  77 => 37,  71 => 34,  67 => 33,  60 => 29,  53 => 25,  50 => 24,  42 => 18,  40 => 17,  32 => 12,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "posting_attach_body.html", "");
    }
}
