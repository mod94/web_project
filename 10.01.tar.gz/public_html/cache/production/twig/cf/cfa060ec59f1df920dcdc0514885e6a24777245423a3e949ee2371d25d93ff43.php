<?php

/* viewforum_body.html */
class __TwigTemplate_69e74c4c5f65b391f7bf9eba1b7f094cef183d041b8c3dc460bd51d9cc90feff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $location = "overall_header.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("overall_header.html", "viewforum_body.html", 1)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 2
        echo "
\t";
        // line 3
        if ((isset($context["S_FORUM_RULES"]) ? $context["S_FORUM_RULES"] : null)) {
            // line 4
            echo "\t";
            if ((isset($context["U_FORUM_RULES"]) ? $context["U_FORUM_RULES"] : null)) {
                // line 5
                echo "\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 7
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_001.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 8
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_002.png) repeat;\" width=\"50%\" height=\"34\"></td>
\t\t\t<td style=\"background:url(";
                // line 9
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/cu0.png);\" width=\"350\" height=\"34\"><h3 align=\"center\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM_RULES");
                echo "</h3></td>
\t\t\t<td style=\"background:url(";
                // line 10
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_002.png) repeat;\" width=\"50%\" height=\"34\"></td>
\t\t\t<td><img src=\"";
                // line 11
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_004.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t</tr>
\t</table>
\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td style=\"background:url(";
                // line 16
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_008.png)\" width=\"34\" height=\"100%\"></td>
\t\t\t<td>  
\t\t\t\t<div class=\"forumrules\">
\t\t\t\t<a href=\"";
                // line 19
                echo (isset($context["U_FORUM_RULES"]) ? $context["U_FORUM_RULES"] : null);
                echo "\"><b>";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM_RULES_LINK");
                echo "</b></a>
\t\t\t\t</div>
\t\t\t</td>
\t\t\t<td style=\"background:url(";
                // line 22
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_009.png)\" width=\"28\" height=\"100%\"></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 25
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_010.png\" width=\"28\" height=\"32\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 26
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_011.png)\" width=\"100%\" height=\"32\"></td>
\t\t\t<td><img src=\"";
                // line 27
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_013.png\" width=\"28\" height=\"32\" alt=\"\" /></td>
\t\t</tr>
\t</table>  
\t";
            } else {
                // line 31
                echo "\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 33
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_001.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 34
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_002.png)\" width=\"50%\" height=\"34\"></td>
\t\t\t<td style=\"background:url(";
                // line 35
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/cu0.png)\" width=\"350\" height=\"34\"><h3 align=\"center\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM_RULES");
                echo "</h3></td>
\t\t\t<td style=\"background:url(";
                // line 36
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_002.png)\" width=\"50%\" height=\"34\"></td>
\t\t\t<td><img src=\"";
                // line 37
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_004.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t</tr>
\t</table>
\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td style=\"background:url(";
                // line 42
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_008.png)\" width=\"34\" height=\"100%\"></td>
\t\t\t<td>
\t\t\t\t<div class=\"forumrules\">
\t\t\t\t";
                // line 45
                echo (isset($context["FORUM_RULES"]) ? $context["FORUM_RULES"] : null);
                echo "
\t\t\t\t</div>
\t\t\t</td>
\t\t\t<td style=\"background:url(";
                // line 48
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_009.png)\" width=\"28\" height=\"100%\"></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 51
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_010.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 52
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_011.png)\" width=\"100%\" height=\"34\"></td>
\t\t\t<td><img src=\"";
                // line 53
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_013.png\" width=\"28\" height=\"34\" alt=\"\" /></td>
\t\t</tr>
\t</table> 
\t";
            }
            // line 57
            echo "\t<br clear=\"all\" />
\t";
        }
        // line 59
        echo "
\t";
        // line 60
        if ((isset($context["S_DISPLAY_ACTIVE"]) ? $context["S_DISPLAY_ACTIVE"] : null)) {
            // line 61
            echo "\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t<tr>
\t\t\t<td class=\"cat\" colspan=\"";
            // line 63
            if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                echo "7";
            } else {
                echo "6";
            }
            echo "\"><span class=\"nav\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ACTIVE_TOPICS");
            echo "</span></td>
\t\t</tr>
\t\t<tr>
\t\t\t";
            // line 66
            if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                // line 67
                echo "\t\t\t<th colspan=\"3\">&nbsp;";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPICS");
                echo "&nbsp;</th>
\t\t\t";
            } else {
                // line 69
                echo "\t\t\t<th colspan=\"2\">&nbsp;";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPICS");
                echo "&nbsp;</th>
\t\t\t";
            }
            // line 71
            echo "\t\t\t<th>&nbsp;";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("AUTHOR");
            echo "&nbsp;</th>
\t\t\t<th>&nbsp;";
            // line 72
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("REPLIES");
            echo "&nbsp;</th>
\t\t\t<th>&nbsp;";
            // line 73
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("VIEWS");
            echo "&nbsp;</th>
\t\t\t<th>&nbsp;";
            // line 74
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LAST_POST");
            echo "&nbsp;</th>
\t\t</tr>

\t";
            // line 77
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "topicrow", array()));
            $context['_iterated'] = false;
            foreach ($context['_seq'] as $context["_key"] => $context["topicrow"]) {
                // line 78
                echo "\t\t<tr>
\t\t\t<td class=\"row1\" width=\"25\" align=\"center\">";
                // line 79
                echo $this->getAttribute($context["topicrow"], "TOPIC_FOLDER_IMG", array());
                echo "</td>
\t\t\t";
                // line 80
                if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                    // line 81
                    echo "\t\t\t\t<td class=\"row1\" width=\"25\" align=\"center\">";
                    if ($this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG", array())) {
                        echo "<img src=\"";
                        echo (isset($context["T_ICONS_PATH"]) ? $context["T_ICONS_PATH"] : null);
                        echo $this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG", array());
                        echo "\" width=\"";
                        echo $this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG_WIDTH", array());
                        echo "\" height=\"";
                        echo $this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG_HEIGHT", array());
                        echo "\" alt=\"\" title=\"\" />";
                    }
                    echo "</td>
\t\t\t";
                }
                // line 83
                echo "\t\t\t<td class=\"row1\">
\t\t\t\t";
                // line 84
                if ($this->getAttribute($context["topicrow"], "S_UNREAD_TOPIC", array())) {
                    echo "<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_NEWEST_POST", array());
                    echo "\">";
                    echo (isset($context["NEWEST_POST_IMG"]) ? $context["NEWEST_POST_IMG"] : null);
                    echo "</a>";
                }
                // line 85
                echo "\t\t\t\t";
                echo $this->getAttribute($context["topicrow"], "ATTACH_ICON_IMG", array());
                echo " ";
                if (($this->getAttribute($context["topicrow"], "S_HAS_POLL", array()) || $this->getAttribute($context["topicrow"], "S_TOPIC_MOVED", array()))) {
                    echo "<b>";
                    echo $this->getAttribute($context["topicrow"], "TOPIC_TYPE", array());
                    echo "</b> ";
                }
                echo "<a title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POSTED");
                echo ": ";
                echo $this->getAttribute($context["topicrow"], "FIRST_POST_TIME", array());
                echo "\" href=\"";
                echo $this->getAttribute($context["topicrow"], "U_VIEW_TOPIC", array());
                echo "\"class=\"topictitle\">";
                echo $this->getAttribute($context["topicrow"], "TOPIC_TITLE", array());
                echo "</a>
\t\t\t\t";
                // line 86
                if (($this->getAttribute($context["topicrow"], "S_TOPIC_UNAPPROVED", array()) || $this->getAttribute($context["topicrow"], "S_POSTS_UNAPPROVED", array()))) {
                    // line 87
                    echo "\t\t\t\t\t<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_MCP_QUEUE", array());
                    echo "\">";
                    echo (isset($context["UNAPPROVED_IMG"]) ? $context["UNAPPROVED_IMG"] : null);
                    echo "</a>&nbsp;
\t\t\t\t";
                }
                // line 89
                echo "\t\t\t\t";
                if ($this->getAttribute($context["topicrow"], "S_TOPIC_REPORTED", array())) {
                    // line 90
                    echo "\t\t\t\t\t<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_MCP_REPORT", array());
                    echo "\">";
                    echo (isset($context["REPORTED_IMG"]) ? $context["REPORTED_IMG"] : null);
                    echo "</a>&nbsp;
\t\t\t\t";
                }
                // line 92
                echo "\t\t\t\t";
                if ($this->getAttribute($context["topicrow"], "PAGINATION", array())) {
                    // line 93
                    echo "\t\t\t\t\t<p class=\"gensmall\"> [ ";
                    echo (isset($context["GOTO_PAGE_IMG"]) ? $context["GOTO_PAGE_IMG"] : null);
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("GOTO_PAGE");
                    echo ": ";
                    echo $this->getAttribute($context["topicrow"], "PAGINATION", array());
                    echo " ] </p>
\t\t\t\t";
                }
                // line 95
                echo "\t\t\t</td>
\t\t\t<td class=\"row2\" width=\"130\" align=\"center\"><p class=\"topicauthor\">";
                // line 96
                echo $this->getAttribute($context["topicrow"], "TOPIC_AUTHOR_FULL", array());
                echo "</p></td>
\t\t\t<td class=\"row1\" width=\"50\" align=\"center\"><p class=\"topicdetails\">";
                // line 97
                echo $this->getAttribute($context["topicrow"], "REPLIES", array());
                echo "</p></td>
\t\t\t<td class=\"row2\" width=\"50\" align=\"center\"><p class=\"topicdetails\">";
                // line 98
                echo $this->getAttribute($context["topicrow"], "VIEWS", array());
                echo "</p></td>
\t\t\t<td class=\"row1\" width=\"140\" align=\"center\">
\t\t\t\t<p class=\"topicdetails\" style=\"white-space: nowrap;\">";
                // line 100
                echo $this->getAttribute($context["topicrow"], "LAST_POST_TIME", array());
                echo "</p>
\t\t\t\t<p class=\"topicdetails\">";
                // line 101
                echo $this->getAttribute($context["topicrow"], "LAST_POST_AUTHOR_FULL", array());
                echo "
\t\t\t\t\t";
                // line 102
                if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
                    echo "<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_LAST_POST", array());
                    echo "\">";
                    echo (isset($context["LAST_POST_IMG"]) ? $context["LAST_POST_IMG"] : null);
                    echo "</a>";
                }
                // line 103
                echo "\t\t\t\t</p>
\t\t\t</td>
\t\t</tr>

\t";
                $context['_iterated'] = true;
            }
            if (!$context['_iterated']) {
                // line 108
                echo "
\t\t<tr>
\t\t\t";
                // line 110
                if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                    // line 111
                    echo "\t\t\t\t<td class=\"row1\" colspan=\"7\" height=\"30\" align=\"center\" valign=\"middle\"><span class=\"gen\">";
                    if ( !(isset($context["S_SORT_DAYS"]) ? $context["S_SORT_DAYS"] : null)) {
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPICS");
                    } else {
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPICS_TIME_FRAME");
                    }
                    echo "</span></td>
\t\t\t";
                } else {
                    // line 113
                    echo "\t\t\t\t<td class=\"row1\" colspan=\"6\" height=\"30\" align=\"center\" valign=\"middle\"><span class=\"gen\">";
                    if ( !(isset($context["S_SORT_DAYS"]) ? $context["S_SORT_DAYS"] : null)) {
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPICS");
                    } else {
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPICS_TIME_FRAME");
                    }
                    echo "</span></td>
\t\t\t";
                }
                // line 115
                echo "\t\t</tr>
\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['topicrow'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 117
            echo "
\t\t<tr align=\"center\">
\t\t\t<td class=\"cat\" colspan=\"";
            // line 119
            if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                echo "7";
            } else {
                echo "6";
            }
            echo "\">&nbsp;</td>
\t\t</tr>
\t</table>

\t<br clear=\"all\" />
";
        }
        // line 125
        echo "
";
        // line 126
        if ((isset($context["S_HAS_SUBFORUM"]) ? $context["S_HAS_SUBFORUM"] : null)) {
            // line 127
            echo "\t";
            $location = "forumlist_body.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("forumlist_body.html", "viewforum_body.html", 127)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
            // line 128
            echo "\t
";
        }
        // line 130
        echo "
";
        // line 131
        if (((isset($context["S_IS_POSTABLE"]) ? $context["S_IS_POSTABLE"] : null) || (isset($context["S_NO_READ_ACCESS"]) ? $context["S_NO_READ_ACCESS"] : null))) {
            // line 132
            echo "<div id=\"pageheader\">
\t<h2><a class=\"titles\" href=\"";
            // line 133
            echo (isset($context["U_VIEW_FORUM"]) ? $context["U_VIEW_FORUM"] : null);
            echo "\">";
            echo (isset($context["FORUM_NAME"]) ? $context["FORUM_NAME"] : null);
            echo "</a></h2>
\t";
            // line 134
            if ((isset($context["MODERATORS"]) ? $context["MODERATORS"] : null)) {
                // line 135
                echo "\t<p class=\"moderators\">";
                if ((isset($context["S_SINGLE_MODERATOR"]) ? $context["S_SINGLE_MODERATOR"] : null)) {
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MODERATOR");
                } else {
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MODERATORS");
                }
                echo ": ";
                echo (isset($context["MODERATORS"]) ? $context["MODERATORS"] : null);
                echo "</p>
\t";
            }
            // line 137
            echo "\t";
            if ((isset($context["U_MCP"]) ? $context["U_MCP"] : null)) {
                // line 138
                echo "\t<p class=\"linkmcp\">

<a 
    href=\"";
                // line 141
                echo (isset($context["U_MCP"]) ? $context["U_MCP"] : null);
                echo "\"
    onmouseover = \"rollover('mod')\" 
    onmouseout  = \"rollout('mod')\" 
    ><img 
    src=\"";
                // line 145
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/buttons/mod1.png\" 
    name=\"mod\" 
    alt=\"Moderator\" border=\"0\" 
    height=\"38\" width=\"180\"
    /></a>
<script type=\"text/javascript\">
<!--
setrollover(\"";
                // line 152
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/buttons/mod2.png\");
//-->
</script>

    </p>
\t";
            }
            // line 158
            echo "</div>

<br clear=\"all\" /><br />
";
        }
        // line 162
        echo "
";
        // line 163
        if ((isset($context["S_NO_READ_ACCESS"]) ? $context["S_NO_READ_ACCESS"] : null)) {
            // line 164
            echo "\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t<tr>
\t\t\t<td class=\"row1\" height=\"30\" align=\"center\" valign=\"middle\"><span class=\"gen\">";
            // line 166
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_READ_ACCESS");
            echo "</span></td>
\t\t</tr>
\t</table>
\t";
            // line 169
            if (( !(isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null) &&  !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null))) {
                // line 170
                echo "\t<br /><br />
\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 173
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 174
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_02.png)\" width=\"100%\" height=\"48\">
\t\t\t<h4><a href=\"";
                // line 175
                echo (isset($context["U_LOGIN_LOGOUT"]) ? $context["U_LOGIN_LOGOUT"] : null);
                echo "\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOGIN_LOGOUT");
                echo "</a>
\t\t\t</td>
\t\t\t<td><img src=\"";
                // line 177
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td style=\"background:url(";
                // line 180
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_08.png)\" width=\"41\" height=\"100%\"></td>
\t\t\t<td>    
\t\t\t\t<form method=\"post\" action=\"";
                // line 182
                echo (isset($context["S_LOGIN_ACTION"]) ? $context["S_LOGIN_ACTION"] : null);
                echo "\">
\t\t\t\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td class=\"row1\" align=\"center\"><span class=\"genmed\">";
                // line 185
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("USERNAME");
                echo ":</span> <input class=\"post\" type=\"text\" name=\"username\" size=\"10\" />&nbsp; <span class=\"genmed\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("PASSWORD");
                echo ":</span> <input class=\"post\" type=\"password\" name=\"password\" size=\"10\" />";
                if ((isset($context["S_AUTOLOGIN_ENABLED"]) ? $context["S_AUTOLOGIN_ENABLED"] : null)) {
                    echo "&nbsp; <span class=\"gensmall\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOG_ME_IN");
                    echo "</span> <input type=\"checkbox\" class=\"radio\" name=\"autologin\" />";
                }
                echo "&nbsp; <input type=\"submit\" class=\"btnmain\" name=\"login\" value=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOGIN");
                echo "\" /></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t\t";
                // line 188
                echo (isset($context["S_LOGIN_REDIRECT"]) ? $context["S_LOGIN_REDIRECT"] : null);
                echo "
\t\t\t\t</form>
\t\t\t</td>
\t\t\t<td style=\"background:url(";
                // line 191
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_09.png)\" width=\"41\" height=\"100%\"></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td><img src=\"";
                // line 194
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t<td style=\"background:url(";
                // line 195
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_11.png)\" width=\"100%\" height=\"46\"></td>
\t\t\t<td><img src=\"";
                // line 196
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t</tr>
\t</table>    


\t";
            }
            // line 202
            echo "
\t<br clear=\"all\" />
";
        }
        // line 205
        echo "
\t";
        // line 206
        if (((isset($context["S_DISPLAY_POST_INFO"]) ? $context["S_DISPLAY_POST_INFO"] : null) || (isset($context["TOTAL_TOPICS"]) ? $context["TOTAL_TOPICS"] : null))) {
            // line 207
            echo "<div id=\"pagecontent\">
\t<table width=\"100%\" cellspacing=\"1\">
\t\t<tr>
\t\t\t";
            // line 210
            if (((isset($context["S_DISPLAY_POST_INFO"]) ? $context["S_DISPLAY_POST_INFO"] : null) &&  !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null))) {
                // line 211
                echo "\t\t\t<td align=\"";
                echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
                echo "\" valign=\"middle\">
\t\t\t<a 
\t\t    href=\"";
                // line 213
                echo (isset($context["U_POST_NEW_TOPIC"]) ? $context["U_POST_NEW_TOPIC"] : null);
                echo "\"
\t\t    onmouseover = \"rollover('new_topic')\" 
\t\t    onmouseout  = \"rollout('new_topic')\" 
\t\t    ><img 
\t\t    src=\"";
                // line 217
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/buttons/new_topic1.png\" 
\t\t    name=\"new_topic\" 
\t\t    alt=\"New Topic\" border=\"0\" 
\t\t    height=\"45\" width=\"120\"
\t\t    /></a>
\t\t\t<script type=\"text/javascript\">
\t\t\t<!--
\t\t\tsetrollover(\"";
                // line 224
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/buttons/new_topic2.png\");
\t\t\t//-->
\t\t\t</script>
\t\t\t</td>
\t\t\t";
            }
            // line 229
            echo "\t\t\t";
            if ((isset($context["TOTAL_TOPICS"]) ? $context["TOTAL_TOPICS"] : null)) {
                // line 230
                echo "\t\t\t<td class=\"nav\" valign=\"middle\" nowrap=\"nowrap\">&nbsp;";
                echo (isset($context["PAGE_NUMBER"]) ? $context["PAGE_NUMBER"] : null);
                echo "<br /></td>
\t\t\t<td class=\"gensmall\" nowrap=\"nowrap\">&nbsp;[ ";
                // line 231
                echo (isset($context["TOTAL_TOPICS"]) ? $context["TOTAL_TOPICS"] : null);
                echo " ]&nbsp;</td>
\t\t\t<td class=\"gensmall\" width=\"100%\" align=\"";
                // line 232
                echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
                echo "\" nowrap=\"nowrap\">";
                $location = "pagination.html";
                $namespace = false;
                if (strpos($location, '@') === 0) {
                    $namespace = substr($location, 1, strpos($location, '/') - 1);
                    $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                    $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
                }
                $this->loadTemplate("pagination.html", "viewforum_body.html", 232)->display($context);
                if ($namespace) {
                    $this->env->setNamespaceLookUpOrder($previous_look_up_order);
                }
                echo "</td>
\t\t\t";
            }
            // line 234
            echo "\t\t</tr>
\t</table>
\t";
        }
        // line 237
        echo "
    ";
        // line 238
        if (( !(isset($context["S_DISPLAY_ACTIVE"]) ? $context["S_DISPLAY_ACTIVE"] : null) && ((isset($context["S_IS_POSTABLE"]) ? $context["S_IS_POSTABLE"] : null) || twig_length_filter($this->env, $this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "topicrow", array()))))) {
            // line 239
            echo "\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><img src=\"";
            // line 244
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 245
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_02.png)\" width=\"100%\" height=\"48\">
\t\t\t\t\t\t\t<table width=\"100%\" cellspacing=\"0\">
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td><h6>&nbsp;";
            // line 248
            if (((isset($context["S_WATCH_FORUM_LINK"]) ? $context["S_WATCH_FORUM_LINK"] : null) &&  !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null))) {
                echo "<a href=\"";
                echo (isset($context["S_WATCH_FORUM_LINK"]) ? $context["S_WATCH_FORUM_LINK"] : null);
                echo "\">";
                echo (isset($context["S_WATCH_FORUM_TITLE"]) ? $context["S_WATCH_FORUM_TITLE"] : null);
                echo "</a>";
            }
            echo "</h6></td>
\t\t\t\t\t\t\t\t\t<td align=\"";
            // line 249
            echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
            echo "\"><h6>";
            if (( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null) && (isset($context["U_MARK_TOPICS"]) ? $context["U_MARK_TOPICS"] : null))) {
                echo "<a href=\"";
                echo (isset($context["U_MARK_TOPICS"]) ? $context["U_MARK_TOPICS"] : null);
                echo "\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MARK_TOPICS_READ");
                echo "</a>";
            }
            echo "&nbsp;</h6></td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t    </td>    
\t\t\t\t\t\t\t<td><img src=\"";
            // line 253
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 262
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_08.png)\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t<table class=\"tablebg\" width=\"100%\" cellspacing=\"1\">
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t";
            // line 266
            if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                // line 267
                echo "\t\t\t\t\t\t\t\t\t<th colspan=\"3\">&nbsp;";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPICS");
                echo "&nbsp;</th>
\t\t\t\t\t\t\t\t\t";
            } else {
                // line 269
                echo "\t\t\t\t\t\t\t\t\t<th colspan=\"2\">&nbsp;";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPICS");
                echo "&nbsp;</th>
\t\t\t\t\t\t\t\t\t";
            }
            // line 271
            echo "\t\t\t\t\t\t\t\t\t<th>&nbsp;";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("AUTHOR");
            echo "&nbsp;</th>
\t\t\t\t\t\t\t\t\t<th>&nbsp;";
            // line 272
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("REPLIES");
            echo "&nbsp;</th>
\t\t\t\t\t\t\t\t\t<th>&nbsp;";
            // line 273
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("VIEWS");
            echo "&nbsp;</th>
\t\t\t\t\t\t\t\t\t<th>&nbsp;";
            // line 274
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LAST_POST");
            echo "&nbsp;</th>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t";
            // line 276
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "topicrow", array()));
            $context['_iterated'] = false;
            foreach ($context['_seq'] as $context["_key"] => $context["topicrow"]) {
                // line 277
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["topicrow"], "S_TOPIC_TYPE_SWITCH", array()) == 1)) {
                    // line 278
                    echo "\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td class=\"row3\" colspan=\"";
                    // line 279
                    if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                        echo "7";
                    } else {
                        echo "6";
                    }
                    echo "\"><b class=\"gensmall\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ANNOUNCEMENTS");
                    echo "</b></td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 281
$context["topicrow"], "S_TOPIC_TYPE_SWITCH", array()) == 0)) {
                    // line 282
                    echo "\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td class=\"row3\" colspan=\"";
                    // line 283
                    if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                        echo "7";
                    } else {
                        echo "6";
                    }
                    echo "\"><b class=\"gensmall\">";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPICS");
                    echo "</b></td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t";
                }
                // line 286
                echo "\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td class=\"row1\" width=\"25\" align=\"center\">";
                // line 287
                echo $this->getAttribute($context["topicrow"], "TOPIC_FOLDER_IMG", array());
                echo "</td>
\t\t\t\t\t\t\t\t\t";
                // line 288
                if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                    // line 289
                    echo "\t\t\t\t\t\t\t\t\t<td class=\"row1\" width=\"25\" align=\"center\">";
                    if ($this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG", array())) {
                        echo "<img src=\"";
                        echo (isset($context["T_ICONS_PATH"]) ? $context["T_ICONS_PATH"] : null);
                        echo $this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG", array());
                        echo "\" width=\"";
                        echo $this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG_WIDTH", array());
                        echo "\" height=\"";
                        echo $this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG_HEIGHT", array());
                        echo "\" alt=\"\" title=\"\" />";
                    }
                    echo "</td>
\t\t\t\t\t\t\t\t\t";
                }
                // line 291
                echo "\t\t\t\t\t\t\t\t\t<td class=\"row1\">
\t\t\t\t\t\t\t\t\t";
                // line 292
                if ($this->getAttribute($context["topicrow"], "S_UNREAD_TOPIC", array())) {
                    echo "<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_NEWEST_POST", array());
                    echo "\">";
                    echo (isset($context["NEWEST_POST_IMG"]) ? $context["NEWEST_POST_IMG"] : null);
                    echo "</a>";
                }
                // line 293
                echo "\t\t\t\t\t\t\t\t\t";
                echo $this->getAttribute($context["topicrow"], "ATTACH_ICON_IMG", array());
                echo " ";
                if (($this->getAttribute($context["topicrow"], "S_HAS_POLL", array()) || $this->getAttribute($context["topicrow"], "S_TOPIC_MOVED", array()))) {
                    echo "<b>";
                    echo $this->getAttribute($context["topicrow"], "TOPIC_TYPE", array());
                    echo "</b> ";
                }
                echo "<a title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POSTED");
                echo ": ";
                echo $this->getAttribute($context["topicrow"], "FIRST_POST_TIME", array());
                echo "\" href=\"";
                echo $this->getAttribute($context["topicrow"], "U_VIEW_TOPIC", array());
                echo "\" class=\"topictitle\">";
                echo $this->getAttribute($context["topicrow"], "TOPIC_TITLE", array());
                echo "</a>
\t\t\t\t\t\t\t\t\t";
                // line 294
                if (($this->getAttribute($context["topicrow"], "S_TOPIC_UNAPPROVED", array()) || $this->getAttribute($context["topicrow"], "S_POSTS_UNAPPROVED", array()))) {
                    // line 295
                    echo "\t\t\t\t\t\t\t\t\t<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_MCP_QUEUE", array());
                    echo "\">";
                    echo $this->getAttribute($context["topicrow"], "UNAPPROVED_IMG", array());
                    echo "</a>&nbsp;
\t\t\t\t\t\t\t\t\t";
                }
                // line 297
                echo "\t\t\t\t\t\t\t\t\t";
                if ($this->getAttribute($context["topicrow"], "S_TOPIC_REPORTED", array())) {
                    // line 298
                    echo "\t\t\t\t\t\t\t\t\t<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_MCP_REPORT", array());
                    echo "\">";
                    echo (isset($context["REPORTED_IMG"]) ? $context["REPORTED_IMG"] : null);
                    echo "</a>&nbsp;
\t\t\t\t\t\t\t\t\t";
                }
                // line 300
                echo "\t\t\t\t\t\t\t\t\t";
                if ($this->getAttribute($context["topicrow"], "PAGINATION", array())) {
                    // line 301
                    echo "\t\t\t\t\t\t\t\t\t<p class=\"gensmall\"> [ ";
                    echo (isset($context["GOTO_PAGE_IMG"]) ? $context["GOTO_PAGE_IMG"] : null);
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("GOTO_PAGE");
                    echo ": ";
                    echo $this->getAttribute($context["topicrow"], "PAGINATION", array());
                    echo " ] </p>
\t\t\t\t\t\t\t\t\t";
                }
                // line 303
                echo "\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t<td class=\"row2\" width=\"130\" align=\"center\"><p class=\"topicauthor\">";
                // line 304
                echo $this->getAttribute($context["topicrow"], "TOPIC_AUTHOR_FULL", array());
                echo "</p></td>
\t\t\t\t\t\t\t\t\t<td class=\"row1\" width=\"50\" align=\"center\"><p class=\"topicdetails\">";
                // line 305
                echo $this->getAttribute($context["topicrow"], "REPLIES", array());
                echo "</p></td>
\t\t\t\t\t\t\t\t\t<td class=\"row2\" width=\"50\" align=\"center\"><p class=\"topicdetails\">";
                // line 306
                echo $this->getAttribute($context["topicrow"], "VIEWS", array());
                echo "</p></td>
\t\t\t\t\t\t\t\t\t<td class=\"row1\" width=\"140\" align=\"center\">
\t\t\t\t\t\t\t\t\t<p class=\"topicdetails\" style=\"white-space: nowrap;\">";
                // line 308
                echo $this->getAttribute($context["topicrow"], "LAST_POST_TIME", array());
                echo "</p>
\t\t\t\t\t\t\t\t\t<p class=\"topicdetails\">";
                // line 309
                echo $this->getAttribute($context["topicrow"], "LAST_POST_AUTHOR_FULL", array());
                echo "
\t\t\t\t\t\t\t\t\t";
                // line 310
                if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
                    echo "<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_LAST_POST", array());
                    echo "\">";
                    echo (isset($context["LAST_POST_IMG"]) ? $context["LAST_POST_IMG"] : null);
                    echo "</a>";
                }
                // line 311
                echo "\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t";
                $context['_iterated'] = true;
            }
            if (!$context['_iterated']) {
                // line 315
                echo "\t\t\t\t\t\t\t\t";
                if ((isset($context["S_IS_POSTABLE"]) ? $context["S_IS_POSTABLE"] : null)) {
                    // line 316
                    echo "\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t";
                    // line 317
                    if ((isset($context["S_TOPIC_ICONS"]) ? $context["S_TOPIC_ICONS"] : null)) {
                        // line 318
                        echo "\t\t\t\t\t\t\t\t\t<td class=\"row1\" colspan=\"7\" height=\"30\" align=\"center\" valign=\"middle\"><span class=\"gen\">";
                        if ( !(isset($context["S_SORT_DAYS"]) ? $context["S_SORT_DAYS"] : null)) {
                            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPICS");
                        } else {
                            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPICS_TIME_FRAME");
                        }
                        echo "</span></td>
\t\t\t\t\t\t\t\t\t";
                    } else {
                        // line 320
                        echo "\t\t\t\t\t\t\t\t\t<td class=\"row1\" colspan=\"6\" height=\"30\" align=\"center\" valign=\"middle\"><span class=\"gen\">";
                        if ( !(isset($context["S_SORT_DAYS"]) ? $context["S_SORT_DAYS"] : null)) {
                            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPICS");
                        } else {
                            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPICS_TIME_FRAME");
                        }
                        echo "</span></td>
\t\t\t\t\t\t\t\t\t";
                    }
                    // line 322
                    echo "\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t";
                }
                // line 324
                echo "\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['topicrow'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 325
            echo "\t\t\t\t\t\t\t\t";
            if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
                // line 326
                echo "\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t<table width=\"100%\" class=\"tablebg\" border=\"0\" cellpadding=\"0\" cellspacing=\"1\" align=\"right\">
\t\t\t\t\t\t\t\t<tr align=\"right\">
\t\t\t\t\t\t\t\t\t<td class=\"row1\" width=\"30%\" align=\"right\">
\t\t\t\t\t\t\t\t\t";
                // line 330
                if ((isset($context["S_DISPLAY_SEARCHBOX"]) ? $context["S_DISPLAY_SEARCHBOX"] : null)) {
                    $location = "searchbox.html";
                    $namespace = false;
                    if (strpos($location, '@') === 0) {
                        $namespace = substr($location, 1, strpos($location, '/') - 1);
                        $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                        $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
                    }
                    $this->loadTemplate("searchbox.html", "viewforum_body.html", 330)->display($context);
                    if ($namespace) {
                        $this->env->setNamespaceLookUpOrder($previous_look_up_order);
                    }
                }
                // line 331
                echo "\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td style=\"background:url(";
                // line 335
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_09.png)\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><img src=\"";
                // line 344
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t\t<td style=\"background:url(";
                // line 345
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_11.png)\" width=\"100%\" height=\"46\" align=\"center\">
\t\t\t\t\t\t<form method=\"post\" action=\"";
                // line 346
                echo (isset($context["S_FORUM_ACTION"]) ? $context["S_FORUM_ACTION"] : null);
                echo "\"><span class=\"gensmall2\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DISPLAY_TOPICS");
                echo ":</span>&nbsp;";
                echo (isset($context["S_SELECT_SORT_DAYS"]) ? $context["S_SELECT_SORT_DAYS"] : null);
                echo "&nbsp;<span class=\"gensmall2\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SORT_BY");
                echo "</span> ";
                echo (isset($context["S_SELECT_SORT_KEY"]) ? $context["S_SELECT_SORT_KEY"] : null);
                echo " ";
                echo (isset($context["S_SELECT_SORT_DIR"]) ? $context["S_SELECT_SORT_DIR"] : null);
                echo "&nbsp;<input class=\"btnlite\" type=\"submit\" name=\"sort\" value=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("GO");
                echo "\" /></form></td>
\t\t\t\t\t\t<td><img src=\"";
                // line 347
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>   
\t\t\t</td>
\t\t</tr>
\t</table> 
\t";
            }
            // line 353
            echo "\t
\t";
        }
        // line 355
        echo "
\t";
        // line 356
        if (((isset($context["S_DISPLAY_POST_INFO"]) ? $context["S_DISPLAY_POST_INFO"] : null) || (isset($context["TOTAL_TOPICS"]) ? $context["TOTAL_TOPICS"] : null))) {
            // line 357
            echo "\t
\t<table width=\"100%\" cellspacing=\"1\">
\t\t<tr>
\t\t\t";
            // line 360
            if (((isset($context["S_DISPLAY_POST_INFO"]) ? $context["S_DISPLAY_POST_INFO"] : null) &&  !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null))) {
                // line 361
                echo "\t\t\t<td align=\"";
                echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
                echo "\" valign=\"middle\">
\t\t\t<a 
\t\t    href=\"";
                // line 363
                echo (isset($context["U_POST_NEW_TOPIC"]) ? $context["U_POST_NEW_TOPIC"] : null);
                echo "\"
\t\t    onmouseover = \"rollover('new_topic2')\" 
\t\t    onmouseout  = \"rollout('new_topic2')\" 
\t\t    ><img 
\t\t\tsrc=\"";
                // line 367
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/buttons/new_topic1.png\" 
\t\t\tname=\"new_topic2\" 
\t\t\talt=\"New Topic\" border=\"0\" 
\t\t\theight=\"45\" width=\"120\"
\t\t\t/></a>
\t\t\t<script type=\"text/javascript\">
\t\t\t<!--
\t\t\tsetrollover(\"";
                // line 374
                echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
                echo "/images/buttons/new_topic2.png\");
\t\t\t//-->
\t\t\t</script>
\t\t\t</td>
\t\t\t";
            }
            // line 379
            echo "\t\t\t";
            if ((isset($context["TOTAL_TOPICS"]) ? $context["TOTAL_TOPICS"] : null)) {
                // line 380
                echo "\t\t\t<td class=\"nav\" valign=\"middle\" nowrap=\"nowrap\">&nbsp;";
                echo (isset($context["PAGE_NUMBER"]) ? $context["PAGE_NUMBER"] : null);
                echo "<br /></td>
\t\t\t<td class=\"gensmall\" nowrap=\"nowrap\">&nbsp;[ ";
                // line 381
                echo (isset($context["TOTAL_TOPICS"]) ? $context["TOTAL_TOPICS"] : null);
                echo " ]&nbsp;</td>
\t\t\t<td class=\"gensmall\" width=\"100%\" align=\"";
                // line 382
                echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
                echo "\" nowrap=\"nowrap\">";
                $location = "pagination.html";
                $namespace = false;
                if (strpos($location, '@') === 0) {
                    $namespace = substr($location, 1, strpos($location, '/') - 1);
                    $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                    $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
                }
                $this->loadTemplate("pagination.html", "viewforum_body.html", 382)->display($context);
                if ($namespace) {
                    $this->env->setNamespaceLookUpOrder($previous_look_up_order);
                }
                echo "</td>
\t\t\t";
            }
            // line 384
            echo "\t\t</tr>
\t</table>
</div>
\t";
        }
        // line 388
        echo "

";
        // line 390
        $location = "breadcrumbs.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("breadcrumbs.html", "viewforum_body.html", 390)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 391
        echo "


";
        // line 394
        if ((isset($context["S_DISPLAY_ONLINE_LIST"]) ? $context["S_DISPLAY_ONLINE_LIST"] : null)) {
            // line 395
            echo "
\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><img src=\"";
            // line 401
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 402
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_02.png)\" width=\"50%\" height=\"48\"></td>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 403
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/cu.png)\" width=\"350\" height=\"48\"><h4 align=\"center\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("WHO_IS_ONLINE");
            echo "</h4></td>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 404
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_02.png)\" width=\"50%\" height=\"48\" align=\"right\"></td>
\t\t\t\t\t\t<td><img src=\"";
            // line 405
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 414
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_08.png)\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t\t<td class=\"row1\"><p class=\"gensmall\">";
            // line 415
            echo (isset($context["LOGGED_IN_USER_LIST"]) ? $context["LOGGED_IN_USER_LIST"] : null);
            echo "</p></td>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 416
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_09.png)\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><img src=\"";
            // line 425
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 426
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_11.png)\" width=\"100%\" height=\"46\"></td>
\t\t\t\t\t\t<td><img src=\"";
            // line 427
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t</tr>
\t\t\t\t</table> 
\t\t\t</td>
\t\t</tr>
\t</table>

";
        }
        // line 435
        echo "
";
        // line 436
        if ((isset($context["S_DISPLAY_POST_INFO"]) ? $context["S_DISPLAY_POST_INFO"] : null)) {
            // line 437
            echo "
\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td>
\t           <table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t        <td><img src=\"";
            // line 443
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t        <td style=\"background:url(";
            // line 444
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_02.png)\" width=\"50%\" height=\"48\"></td>
\t\t\t\t        <td style=\"background:url(";
            // line 445
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_02.png)\" width=\"50%\" height=\"48\"></td>
\t\t\t\t        <td><img src=\"";
            // line 446
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_04.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t</tr>
\t            </table>
\t\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>
\t            <table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 455
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_08.png)\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t\t<td>  
\t\t\t\t\t\t\t<table class=\"row1\" width=\"100%\" cellspacing=\"0\" border=\"0\">
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td align=\"";
            // line 459
            echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
            echo "\" valign=\"top\">
\t\t\t\t\t\t\t\t\t\t<table class=\"row1\" cellspacing=\"3\" cellpadding=\"0\" border=\"0\">
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td width=\"20\" style=\"text-align: center;\">";
            // line 462
            echo (isset($context["FOLDER_UNREAD_IMG"]) ? $context["FOLDER_UNREAD_IMG"] : null);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 463
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("UNREAD_POSTS");
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>&nbsp;&nbsp;</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td width=\"20\" style=\"text-align: center;\">";
            // line 465
            echo (isset($context["FOLDER_IMG"]) ? $context["FOLDER_IMG"] : null);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 466
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_UNREAD_POSTS");
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>&nbsp;&nbsp;</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td width=\"20\" style=\"text-align: center;\">";
            // line 468
            echo (isset($context["FOLDER_ANNOUNCE_IMG"]) ? $context["FOLDER_ANNOUNCE_IMG"] : null);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 469
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ICON_ANNOUNCEMENT");
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td style=\"text-align: center;\">";
            // line 472
            echo (isset($context["FOLDER_HOT_UNREAD_IMG"]) ? $context["FOLDER_HOT_UNREAD_IMG"] : null);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 473
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("UNREAD_POSTS_HOT");
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>&nbsp;&nbsp;</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td style=\"text-align: center;\">";
            // line 475
            echo (isset($context["FOLDER_HOT_IMG"]) ? $context["FOLDER_HOT_IMG"] : null);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 476
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_UNREAD_POSTS_HOT");
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>&nbsp;&nbsp;</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td style=\"text-align: center;\">";
            // line 478
            echo (isset($context["FOLDER_STICKY_IMG"]) ? $context["FOLDER_STICKY_IMG"] : null);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 479
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ICON_STICKY");
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td style=\"text-align: center;\">";
            // line 482
            echo (isset($context["FOLDER_LOCKED_UNREAD_IMG"]) ? $context["FOLDER_LOCKED_UNREAD_IMG"] : null);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 483
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("UNREAD_POSTS_LOCKED");
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>&nbsp;&nbsp;</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td style=\"text-align: center;\">";
            // line 485
            echo (isset($context["FOLDER_LOCKED_IMG"]) ? $context["FOLDER_LOCKED_IMG"] : null);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 486
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_UNREAD_POSTS_LOCKED");
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td>&nbsp;&nbsp;</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td style=\"text-align: center;\">";
            // line 488
            echo (isset($context["FOLDER_MOVED_IMG"]) ? $context["FOLDER_MOVED_IMG"] : null);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"gensmall\">";
            // line 489
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC_MOVED");
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t<td align=\"";
            // line 493
            echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
            echo "\" valign=\"top\">
\t\t\t\t\t\t\t\t\t\t<table cellspacing=\"3\" cellpadding=\"0\" border=\"0\" align=\"";
            // line 494
            echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td align=\"";
            // line 496
            echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
            echo "\" ><span class=\"gensmall\">";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "rules", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["rules"]) {
                echo $this->getAttribute($context["rules"], "RULE", array());
                echo "<br />";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['rules'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "</span></td>
\t\t\t\t\t\t\t                </tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"spacer\" height=\"1\"><img src=\"images/spacer.gif\" alt=\"\" width=\"1\" height=\"1\" /></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td align=\"";
            // line 502
            echo (isset($context["S_CONTENT_FLOW_END"]) ? $context["S_CONTENT_FLOW_END"] : null);
            echo "\" valign=\"bottom\">";
            $location = "jumpbox.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("jumpbox.html", "viewforum_body.html", 502)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
            echo "</td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 509
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_09.png)\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><img src=\"";
            // line 518
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t\t<td style=\"background:url(";
            // line 519
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_11.png)\" width=\"100%\" height=\"46\"></td>
\t\t\t\t\t\t<td><img src=\"";
            // line 520
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t</td>
\t\t</tr>
\t</table>
\t\t

";
        }
        // line 529
        echo "



";
        // line 533
        $location = "overall_footer.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("overall_footer.html", "viewforum_body.html", 533)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
    }

    public function getTemplateName()
    {
        return "viewforum_body.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1461 => 533,  1455 => 529,  1443 => 520,  1439 => 519,  1435 => 518,  1423 => 509,  1401 => 502,  1382 => 496,  1377 => 494,  1373 => 493,  1366 => 489,  1362 => 488,  1357 => 486,  1353 => 485,  1348 => 483,  1344 => 482,  1338 => 479,  1334 => 478,  1329 => 476,  1325 => 475,  1320 => 473,  1316 => 472,  1310 => 469,  1306 => 468,  1301 => 466,  1297 => 465,  1292 => 463,  1288 => 462,  1282 => 459,  1275 => 455,  1263 => 446,  1259 => 445,  1255 => 444,  1251 => 443,  1243 => 437,  1241 => 436,  1238 => 435,  1227 => 427,  1223 => 426,  1219 => 425,  1207 => 416,  1203 => 415,  1199 => 414,  1187 => 405,  1183 => 404,  1177 => 403,  1173 => 402,  1169 => 401,  1161 => 395,  1159 => 394,  1154 => 391,  1142 => 390,  1138 => 388,  1132 => 384,  1115 => 382,  1111 => 381,  1106 => 380,  1103 => 379,  1095 => 374,  1085 => 367,  1078 => 363,  1072 => 361,  1070 => 360,  1065 => 357,  1063 => 356,  1060 => 355,  1056 => 353,  1046 => 347,  1030 => 346,  1026 => 345,  1022 => 344,  1010 => 335,  1004 => 331,  990 => 330,  984 => 326,  981 => 325,  975 => 324,  971 => 322,  961 => 320,  951 => 318,  949 => 317,  946 => 316,  943 => 315,  935 => 311,  927 => 310,  923 => 309,  919 => 308,  914 => 306,  910 => 305,  906 => 304,  903 => 303,  894 => 301,  891 => 300,  883 => 298,  880 => 297,  872 => 295,  870 => 294,  851 => 293,  843 => 292,  840 => 291,  825 => 289,  823 => 288,  819 => 287,  816 => 286,  804 => 283,  801 => 282,  799 => 281,  788 => 279,  785 => 278,  782 => 277,  777 => 276,  772 => 274,  768 => 273,  764 => 272,  759 => 271,  753 => 269,  747 => 267,  745 => 266,  738 => 262,  726 => 253,  711 => 249,  701 => 248,  695 => 245,  691 => 244,  684 => 239,  682 => 238,  679 => 237,  674 => 234,  657 => 232,  653 => 231,  648 => 230,  645 => 229,  637 => 224,  627 => 217,  620 => 213,  614 => 211,  612 => 210,  607 => 207,  605 => 206,  602 => 205,  597 => 202,  588 => 196,  584 => 195,  580 => 194,  574 => 191,  568 => 188,  552 => 185,  546 => 182,  541 => 180,  535 => 177,  528 => 175,  524 => 174,  520 => 173,  515 => 170,  513 => 169,  507 => 166,  503 => 164,  501 => 163,  498 => 162,  492 => 158,  483 => 152,  473 => 145,  466 => 141,  461 => 138,  458 => 137,  446 => 135,  444 => 134,  438 => 133,  435 => 132,  433 => 131,  430 => 130,  426 => 128,  413 => 127,  411 => 126,  408 => 125,  395 => 119,  391 => 117,  384 => 115,  374 => 113,  364 => 111,  362 => 110,  358 => 108,  349 => 103,  341 => 102,  337 => 101,  333 => 100,  328 => 98,  324 => 97,  320 => 96,  317 => 95,  308 => 93,  305 => 92,  297 => 90,  294 => 89,  286 => 87,  284 => 86,  265 => 85,  257 => 84,  254 => 83,  239 => 81,  237 => 80,  233 => 79,  230 => 78,  225 => 77,  219 => 74,  215 => 73,  211 => 72,  206 => 71,  200 => 69,  194 => 67,  192 => 66,  180 => 63,  176 => 61,  174 => 60,  171 => 59,  167 => 57,  160 => 53,  156 => 52,  152 => 51,  146 => 48,  140 => 45,  134 => 42,  126 => 37,  122 => 36,  116 => 35,  112 => 34,  108 => 33,  104 => 31,  97 => 27,  93 => 26,  89 => 25,  83 => 22,  75 => 19,  69 => 16,  61 => 11,  57 => 10,  51 => 9,  47 => 8,  43 => 7,  39 => 5,  36 => 4,  34 => 3,  31 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "viewforum_body.html", "");
    }
}
