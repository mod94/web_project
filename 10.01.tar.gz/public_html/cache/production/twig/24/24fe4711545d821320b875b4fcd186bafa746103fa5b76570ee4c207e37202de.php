<?php

/* pagination.html */
class __TwigTemplate_3dff57a4f8011315d2b1453cb7c91398b2469e56697ea852eb3199437bb6d875 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ((isset($context["PAGINATION"]) ? $context["PAGINATION"] : null)) {
            // line 2
            echo "<table id=\"bx\" border=\"0\">
<tr>
<b>

<a href=\"#\" onclick=\"jumpto(); return false;\" title=\"";
            // line 6
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("JUMP_TO_PAGE");
            echo "\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("GOTO_PAGE");
            echo "</a> 


";
            // line 9
            if ((isset($context["PREVIOUS_PAGE"]) ? $context["PREVIOUS_PAGE"] : null)) {
                // line 10
                echo "<td>
<table id=\"bx\" bgcolor=\"#262626\" border=\"1\">
<tr>
<td>
&nbsp;<a href=\"";
                // line 14
                echo (isset($context["PREVIOUS_PAGE"]) ? $context["PREVIOUS_PAGE"] : null);
                echo "\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("PREVIOUS");
                echo "</a> <<&nbsp;
</td>
</tr>
</table>
";
            }
            // line 19
            echo "</td>
<td>

<table id=\"bx\" bgcolor=\"#262626\" border=\"1\">
<tr>
<td>

";
            // line 26
            echo (isset($context["PAGINATION"]) ? $context["PAGINATION"] : null);
            echo "
</td>
</tr>
</table>



</td>


";
            // line 36
            if ((isset($context["NEXT_PAGE"]) ? $context["NEXT_PAGE"] : null)) {
                echo " 
<td>
<table id=\"bx\" bgcolor=\"#262626\" border=\"1\">
<tr>
<td>
&nbsp;>> <a href=\"";
                // line 41
                echo (isset($context["NEXT_PAGE"]) ? $context["NEXT_PAGE"] : null);
                echo "\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NEXT");
                echo "</a>&nbsp;
</td>
</tr>
</table>
";
            }
            // line 46
            echo "
</b>
</tr>
</table>
";
        }
    }

    public function getTemplateName()
    {
        return "pagination.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 46,  83 => 41,  75 => 36,  62 => 26,  53 => 19,  43 => 14,  37 => 10,  35 => 9,  27 => 6,  21 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "pagination.html", "");
    }
}
