<?php

/* message_body.html */
class __TwigTemplate_8991c65a95e5bc48cdfad2ad3f3ab23ab3b3176c5b0be834e55f541d79b8ae38 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $location = "overall_header.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("overall_header.html", "message_body.html", 1)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 2
        echo "

\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t<tr>
\t\t\t<td>
\t\t\t\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><img src=\"";
        // line 9
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_01.png\" width=\"41\" height=\"48\" alt=\"\" /></td>
\t\t\t\t\t\t<td style=\"background:url(";
        // line 10
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_02.png);\" width=\"50%\" height=\"48\"></td>
\t\t\t\t\t\t<td style=\"background:url(";
        // line 11
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/cu.png);\" width=\"300\" height=\"48\">
\t\t\t\t\t\t<h4 align=\"center\">";
        // line 12
        echo (isset($context["MESSAGE_TITLE"]) ? $context["MESSAGE_TITLE"] : null);
        echo "</h4></td>
\t\t\t\t\t\t<td style=\"background:url(";
        // line 13
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_02.png);\" width=\"50%\" height=\"48\"></td>
\t\t\t\t\t\t<td><img src=\"";
        // line 14
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_04.png\" width=\"41\" height=\"48\" align=\"right\" alt=\"\" /></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td style=\"background:url(";
        // line 19
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_08.png);\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t\t<td>\t
\t\t\t\t\t\t\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td class=\"row1\" align=\"center\"><br /><p class=\"gen\">";
        // line 23
        echo (isset($context["MESSAGE_TEXT"]) ? $context["MESSAGE_TEXT"] : null);
        echo "</p><br /></td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td style=\"background:url(";
        // line 27
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_09.png);\" width=\"41\" height=\"100%\"></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>\t\t\t
\t\t\t\t<table width=\"100%\" style=\"height:44\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td><img src=\"";
        // line 32
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_10.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t\t<td style=\"background:url(";
        // line 33
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_11.png);\" width=\"100%\" height=\"46\"></td>
\t\t\t\t\t\t<td><img src=\"";
        // line 34
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/box_13.png\" width=\"41\" height=\"46\" alt=\"\" /></td>
\t\t\t\t\t</tr>
\t\t\t\t</table>\t
\t\t\t</td>
\t\t</tr>
\t</table>
\t<br clear=\"all\" />

";
        // line 42
        $location = "breadcrumbs.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("breadcrumbs.html", "message_body.html", 42)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 43
        echo "
";
        // line 44
        $location = "overall_footer.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("overall_footer.html", "message_body.html", 44)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
    }

    public function getTemplateName()
    {
        return "message_body.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 44,  121 => 43,  109 => 42,  98 => 34,  94 => 33,  90 => 32,  82 => 27,  75 => 23,  68 => 19,  60 => 14,  56 => 13,  52 => 12,  48 => 11,  44 => 10,  40 => 9,  31 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "message_body.html", "");
    }
}
