<?php

/* overall_footer.html */
class __TwigTemplate_819196b63c3e608dfab9a93caf988a785bc033619f7233298fd4d772126311b6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t
\t";
        // line 2
        if ( !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null)) {
            echo (isset($context["RUN_CRON_TASK"]) ? $context["RUN_CRON_TASK"] : null);
        }
        // line 3
        echo "</div>

<!--
\tWe request you retain the full copyright notice below including the link to www.phpbb.com.
\tThis not only gives respect to the large amount of time given freely by the developers
\tbut also helps build interest, traffic and use of phpBB3. If you (honestly) cannot retain
\tthe full copyright we ask you at least leave in place the \"Powered by phpBB\" line, with
\t\"phpBB\" linked to www.phpbb.com. If you refuse to include even this then support on our
\tforums may be affected.

\tThe phpBB Group : 2006
//-->

<div id=\"wrapfooter\">
\t";
        // line 17
        if ((isset($context["U_ACP"]) ? $context["U_ACP"] : null)) {
            // line 18
            echo "
<span class=\"gensmall\">

<a href=\"";
            // line 21
            echo (isset($context["U_ACP"]) ? $context["U_ACP"] : null);
            echo "\"
    onmouseover = \"rollover('admin')\" 
    onmouseout  = \"rollout('admin')\" 
    ><img 
    src=\"";
            // line 25
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/admin1.png\" 
    name=\"admin\" 
    alt=\"Admin\" border=\"0\" 
    height=\"38\" width=\"180\"
    /></a>
<script type=\"text/javascript\">
<!--
setrollover(\"";
            // line 32
            echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
            echo "/images/buttons/admin2.png\");
//-->
</script>


</span>

<br /><br />
";
        }
        // line 41
        echo "
</div>

<table width=\"100%\" style=\"height:99\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t<tr>
                 <td><img src=\"";
        // line 46
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_01.png\" width=\"81\" height=\"99\" alt=\"\" /></td>
                 <td style=\"background:url(";
        // line 47
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_02.png) repeat;\" width=\"100%\" height=\"99\"></td>
                 <td><img src=\"";
        // line 48
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_03.png\" width=\"82\" height=\"99\" alt=\"\" /></td>
\t</tr>
</table>


<table width=\"100%\" style=\"height:89\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
\t<tr>
                 <td><img src=\"";
        // line 55
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_10.png\" width=\"81\" height=\"89\" alt=\"\" /></td>
                 <td><a href=\"http://www.phpbb.com\"><img src=\"";
        // line 56
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_11.png\" width=\"170\" height=\"89\" alt=\"\" /></a></td>
                 <td style=\"background:url(";
        // line 57
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_12.png) repeat;\" width=\"50%\" height=\"89\"></td>
                 <td><a href=\"http://www.skin-lab.com\"><img src=\"";
        // line 58
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_13.png\" width=\"120\" height=\"89\" alt=\"\" /></a></td>
                 <td style=\"background:url(";
        // line 59
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_12.png) repeat;\" width=\"50%\" height=\"89\"></td>
                 <td><a href=\"http://www.skin-lab.com\"><img src=\"";
        // line 60
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_14.png\" width=\"170\" height=\"89\" alt=\"\" /></a></td>
                 <td><img src=\"";
        // line 61
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/footer/f_15.png\" width=\"82\" height=\"89\" alt=\"\" /></td>
\t</tr>
</table>

<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\">
                 
<tr>
<td align=\"center\">
<span class=\"copyright\">Powered by <a href=\"http://www.skin-lab.com\">Skin-Lab</a> &copy; Alpha Trion
";
        // line 70
        if ((isset($context["TRANSLATION_INFO"]) ? $context["TRANSLATION_INFO"] : null)) {
            echo "<br />";
            echo (isset($context["TRANSLATION_INFO"]) ? $context["TRANSLATION_INFO"] : null);
        }
        // line 71
        echo "\t";
        if ((isset($context["DEBUG_OUTPUT"]) ? $context["DEBUG_OUTPUT"] : null)) {
            echo "<br /><bdo dir=\"ltr\">[ ";
            echo (isset($context["DEBUG_OUTPUT"]) ? $context["DEBUG_OUTPUT"] : null);
            echo " ]</bdo>";
        }
        echo "</span>
</td>
</tr>
</table>

</body>
</html>";
    }

    public function getTemplateName()
    {
        return "overall_footer.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 71,  139 => 70,  127 => 61,  123 => 60,  119 => 59,  115 => 58,  111 => 57,  107 => 56,  103 => 55,  93 => 48,  89 => 47,  85 => 46,  78 => 41,  66 => 32,  56 => 25,  49 => 21,  44 => 18,  42 => 17,  26 => 3,  22 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall_footer.html", "");
    }
}
